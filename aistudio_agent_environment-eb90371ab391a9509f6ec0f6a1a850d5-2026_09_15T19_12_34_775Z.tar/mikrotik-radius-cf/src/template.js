// ====================================================================
// FRONTEND TEMPLATE: MIKROTIK RADIUS CONTROL CENTER
// iOS 27 Liquid Glass Light Theme
// ====================================================================

export function renderHTML() {
  return `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MikroTik RADIUS Control Center - Enterprise Pro</title>
    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        :root {
            --bg-base: #f0f4fc;
            --glass-bg: rgba(255, 255, 255, 0.76);
            --glass-card: rgba(255, 255, 255, 0.65);
            --glass-border: rgba(255, 255, 255, 0.9);
            --glass-border-subtle: rgba(255, 255, 255, 0.4);
            --accent: #007aff;
            --accent-glow: rgba(0, 122, 255, 0.28);
            --accent-soft: rgba(0, 122, 255, 0.08);
            --success: #34c759;
            --success-glow: rgba(52, 199, 89, 0.25);
            --danger: #ff3b30;
            --warning: #ff9500;
            --purple: #af52de;
            --indigo: #5856d6;
            --text-main: #1c1c1e;
            --text-sub: #636366;
            --text-muted: #8e8e93;
            --shadow-glass: 0 12px 36px rgba(10, 45, 100, 0.04), 0 2px 6px rgba(0,0,0,0.01);
            --shadow-float: 0 24px 60px rgba(0, 30, 80, 0.12), 0 4px 12px rgba(0,0,0,0.03);
            --shadow-glow: 0 8px 24px rgba(0, 122, 255, 0.2);
            --radius-xl: 22px;
            --radius-lg: 16px;
            --radius-md: 12px;
            --radius-sm: 8px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Segoe UI", Roboto, sans-serif; -webkit-font-smoothing: antialiased; }
        body { background-color: var(--bg-base); color: var(--text-main); overflow: hidden; height: 100vh; display: flex; position: relative; }

        /* --- LIQUID MESH BACKGROUND (iOS 27 Dynamic Fluid Mesh) --- */
        .liquid-bg { position: fixed; inset: 0; z-index: -1; pointer-events: none; overflow: hidden; }
        .orb { position: absolute; border-radius: 50%; filter: blur(90px); opacity: 0.65; animation: floatOrb 22s infinite alternate ease-in-out; }
        .orb-1 { width: 650px; height: 650px; top: -120px; left: -100px; background: radial-gradient(circle, rgba(200,225,255,0.9) 0%, rgba(220,240,255,0.4) 70%, transparent 100%); }
        .orb-2 { width: 750px; height: 750px; bottom: -180px; right: -120px; background: radial-gradient(circle, rgba(235,220,255,0.85) 0%, rgba(210,235,255,0.5) 60%, transparent 100%); animation-delay: -7s; }
        .orb-3 { width: 500px; height: 500px; top: 40%; left: 35%; background: radial-gradient(circle, rgba(215,245,235,0.6) 0%, rgba(240,230,255,0.2) 70%, transparent 100%); animation-delay: -14s; }
        @keyframes floatOrb {
            0% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(60px, 40px) scale(1.08); }
            100% { transform: translate(-40px, 70px) scale(0.95); }
        }

        /* --- GLASS PANEL SYSTEM --- */
        .glass-panel {
            background: var(--glass-bg);
            backdrop-filter: blur(40px) saturate(200%);
            -webkit-backdrop-filter: blur(40px) saturate(200%);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow-glass);
            position: relative;
        }
        .glass-card-inner {
            background: var(--glass-card);
            backdrop-filter: blur(25px) saturate(180%);
            border: 1px solid var(--glass-border-subtle);
            border-radius: var(--radius-lg);
            box-shadow: 0 4px 16px rgba(0,0,0,0.02);
        }

        /* --- iOS 27 INPUTS & BUTTONS --- */
        .input-ios {
            width: 100%;
            padding: 13px 16px;
            margin-bottom: 12px;
            border: 1px solid rgba(0,0,0,0.06);
            border-radius: var(--radius-md);
            background: rgba(255,255,255,0.85);
            font-size: 13.5px;
            outline: none;
            transition: all 0.25s cubic-bezier(0.2, 0.8, 0.2, 1);
            font-weight: 500;
            color: var(--text-main);
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.02);
        }
        .input-ios:focus {
            border-color: var(--accent);
            background: #ffffff;
            box-shadow: 0 0 0 4px var(--accent-glow);
        }
        textarea.input-ios { resize: vertical; min-height: 80px; }
        select.input-ios { appearance: none; cursor: pointer; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%238e8e93' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 14px center; padding-right: 36px; }

        .btn-ios {
            padding: 12px 20px;
            border: none;
            border-radius: var(--radius-md);
            background: linear-gradient(180deg, #007aff 0%, #006adc 100%);
            color: #ffffff;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.2, 0.8, 0.2, 1);
            box-shadow: var(--shadow-glow);
            text-align: center;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            user-select: none;
        }
        .btn-ios:hover { transform: translateY(-1px); filter: brightness(1.05); }
        .btn-ios:active { transform: scale(0.96); filter: brightness(0.95); }
        .btn-ios:disabled { background: #c7c7cc !important; color: #fff !important; cursor: not-allowed !important; box-shadow: none !important; transform: none !important; opacity: 0.7; }
        
        .btn-outline { background: rgba(255,255,255,0.75); border: 1px solid rgba(0, 122, 255, 0.35); color: var(--accent); box-shadow: none; }
        .btn-outline:hover { background: rgba(0, 122, 255, 0.08); }
        .btn-danger { background: rgba(255, 59, 48, 0.1); color: var(--danger); border: 1px solid rgba(255, 59, 48, 0.25); box-shadow: none; }
        .btn-danger:hover { background: rgba(255, 59, 48, 0.18); }
        .btn-warning { background: rgba(255, 149, 0, 0.12); color: var(--warning); border: 1px solid rgba(255, 149, 0, 0.3); box-shadow: none; }
        .btn-warning:hover { background: rgba(255, 149, 0, 0.2); }
        .btn-success { background: rgba(52, 199, 89, 0.12); color: var(--success); border: 1px solid rgba(52, 199, 89, 0.3); box-shadow: none; }
        .btn-success:hover { background: rgba(52, 199, 89, 0.2); }
        .btn-purple { background: rgba(175, 82, 222, 0.12); color: var(--purple); border: 1px solid rgba(175, 82, 222, 0.3); box-shadow: none; }
        .btn-purple:hover { background: rgba(175, 82, 222, 0.2); }

        /* BADGES */
        .badge { padding: 4px 10px; border-radius: 20px; font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.6px; display: inline-flex; align-items: center; gap: 4px; }
        .badge-active { background: rgba(52,199,89,0.15); color: #28a745; border: 1px solid rgba(52,199,89,0.25); }
        .badge-danger { background: rgba(255,59,48,0.15); color: var(--danger); border: 1px solid rgba(255,59,48,0.25); }
        .badge-warning { background: rgba(255,149,0,0.15); color: #d97706; border: 1px solid rgba(255,149,0,0.25); }
        .badge-pending { background: rgba(255,149,0,0.15); color: #d97706; border: 1px solid rgba(255,149,0,0.25); }
        .badge-purple { background: rgba(175,82,222,0.15); color: var(--purple); border: 1px solid rgba(175,82,222,0.25); }
        .badge-gray { background: rgba(142,142,147,0.15); color: var(--text-sub); }
        .status-pill { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 20px; font-size: 0.7rem; font-weight: 700; background: rgba(0,0,0,0.04); border: 1px solid rgba(0,0,0,0.05); }
        .status-dot { width: 7px; height: 7px; border-radius: 50%; }

        /* --- DYNAMIC ISLAND v2 (Apple Capsule) --- */
        #dynamic-island {
            position: relative;
            height: 42px;
            min-width: 42px;
            border-radius: 21px;
            background: rgba(20, 20, 24, 0.92);
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.45s cubic-bezier(0.34, 1.56, 0.64, 1);
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.18);
            border: 1px solid rgba(255,255,255,0.15);
        }
        #dynamic-island:hover { background: rgba(10, 10, 12, 0.98); transform: scale(1.02); }
        #dynamic-island.active { min-width: 250px; padding: 0 20px; border-radius: 22px; }
        #dynamic-island.active.expand { min-width: 320px; }
        
        .di-bell { position: absolute; display: flex; align-items: center; justify-content: center; width: 100%; height: 100%; transition: opacity 0.25s, transform 0.4s; }
        #dynamic-island.active .di-bell { opacity: 0; transform: scale(0.4) translateY(-15px); pointer-events: none; }
        
        .di-content-wrapper { display: flex; align-items: center; gap: 10px; opacity: 0; transform: scale(0.8) translateY(15px); transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); pointer-events: none; white-space: nowrap; font-size: 12.5px; font-weight: 600; }
        #dynamic-island.active .di-content-wrapper { opacity: 1; transform: scale(1) translateY(0); pointer-events: auto; }
        .di-icon { font-size: 15px; animation: pulseDi 1.6s infinite; }
        @keyframes pulseDi { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.15); } }
        .di-loader { width: 15px; height: 15px; border: 2px solid rgba(255,255,255,0.25); border-top-color: #fff; border-radius: 50%; animation: spinSvg 0.8s linear infinite; }

        /* --- SCREENS & MODALS --- */
        #login-screen, #checklist-screen, #login-pin-screen, #greeting-screen {
            position: fixed; inset: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 9999;
            background: var(--bg-base); transition: opacity 0.4s ease, transform 0.4s ease;
        }
        #greeting-screen { background: rgba(240, 244, 252, 0.82); backdrop-filter: blur(30px); }
        .login-card { width: 90%; max-width: 360px; padding: 40px 32px; text-align: center; }

        .chk-list { list-style: none; padding: 0; margin: 18px 0; max-height: 240px; overflow-y: auto; text-align: left; border-top: 1px solid rgba(0,0,0,0.06); border-bottom: 1px solid rgba(0,0,0,0.06); }
        .chk-list::-webkit-scrollbar { display: none; }
        .chk-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; font-size: 12.5px; font-weight: 600; color: var(--text-main); opacity: 0; transform: translateY(8px); transition: all 0.28s ease; }
        .chk-item.show { opacity: 1; transform: translateY(0); }
        .chk-icon { width: 18px; height: 18px; display: flex; justify-content: center; align-items: center; font-size: 10px; border-radius: 50%; flex-shrink: 0; }
        .chk-spin { border: 2px solid rgba(0,0,0,0.1); border-top-color: var(--accent); border-radius: 50%; animation: spinSvg 0.8s linear infinite; }
        .chk-ok { background: var(--success); color: white; }
        .chk-fail { background: var(--danger); color: white; }

        @keyframes shake { 0%, 100% { transform: translateX(0); } 20%, 60% { transform: translateX(-10px); } 40%, 80% { transform: translateX(10px); } }
        .shake-err { animation: shake 0.4s; }

        .greet-box { width: 92%; max-width: 480px; padding: 36px; text-align: center; transform: scale(0.9); opacity: 0; animation: popIn 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; }
        @keyframes popIn { to { transform: scale(1); opacity: 1; } }
        @keyframes fadeScaleOut { to { transform: scale(1.08); opacity: 0; } }
        .greet-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin: 20px 0; text-align: left; }
        .greet-item { display: flex; align-items: center; gap: 8px; font-size: 11.5px; font-weight: 600; padding: 9px 12px; background: rgba(255,255,255,0.7); border: 1px solid rgba(255,255,255,0.8); border-radius: 12px; box-shadow: 0 2px 6px rgba(0,0,0,0.02); }
        .greet-summary { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; }
        .greet-sum-card { padding: 14px; background: rgba(255,255,255,0.8); border: 1px solid rgba(255,255,255,0.9); border-radius: 14px; text-align: left; }

        .overlay { position: fixed; inset: 0; background: rgba(15, 25, 45, 0.35); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); display: none; justify-content: center; align-items: center; z-index: 4000; opacity: 0; transition: opacity 0.3s ease; padding: 20px; }
        .overlay.show { display: flex; opacity: 1; }
        .popup-box { width: 100%; max-width: 620px; padding: 32px; position: relative; transform: scale(0.94); transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); max-height: 90vh; overflow-y: auto; }
        .overlay.show .popup-box { transform: scale(1); }
        .close-btn { position: absolute; top: 22px; right: 22px; cursor: pointer; background: rgba(0,0,0,0.05); border: none; width: 32px; height: 32px; border-radius: 16px; font-weight: 700; color: var(--text-main); transition: background 0.2s; z-index: 10; display: flex; align-items: center; justify-content: center; }
        .close-btn:hover { background: rgba(0,0,0,0.12); }

        /* --- SPLASH SCREEN --- */
        #splash-screen { position: fixed; inset: 0; background: var(--bg-base); z-index: 10000; display: none; justify-content: center; align-items: center; flex-direction: column; transition: opacity 0.5s ease; }
        .splash-logo { font-size: 3.6rem; font-weight: 800; color: var(--accent); letter-spacing: 1.5px; border-right: 4px solid var(--accent); padding-right: 6px; animation: blinkCaret 0.75s step-end infinite; }
        .splash-sub { font-size: 11px; font-weight: 700; color: var(--text-sub); letter-spacing: 4px; margin-top: 16px; opacity: 0; transition: opacity 1s ease; }
        @keyframes blinkCaret { from, to { border-color: transparent } 50% { border-color: var(--accent); } }

        /* --- MAIN LAYOUT & SIDEBAR --- */
        #app-layout { width: 100%; height: 100vh; display: none; padding: 15px; gap: 15px; opacity: 0; transition: opacity 0.4s ease; position: relative; }
        .brand { font-size: 1.25rem; font-weight: 800; padding: 8px 12px 22px; color: var(--accent); letter-spacing: -0.5px; text-align: center; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .brand-badge { font-size: 9px; padding: 2px 7px; background: rgba(0, 122, 255, 0.12); color: var(--accent); border-radius: 6px; font-weight: 800; text-transform: uppercase; }
        
        .nav-item { padding: 11px 14px; border-radius: var(--radius-md); cursor: pointer; font-weight: 500; font-size: 13.5px; color: var(--text-sub); transition: all 0.2s ease; display: flex; justify-content: space-between; align-items: center; }
        .nav-item:hover { background: rgba(0,0,0,0.035); color: var(--text-main); }
        .nav-item.active { background: #ffffff; color: var(--accent); box-shadow: 0 4px 14px rgba(0,0,0,0.04); font-weight: 700; }
        .nav-group { margin-bottom: 3px; }
        .nav-header { padding: 11px 14px; border-radius: var(--radius-md); cursor: pointer; font-weight: 600; font-size: 13px; color: var(--text-main); display: flex; justify-content: space-between; align-items: center; transition: background 0.2s; }
        .nav-header:hover { background: rgba(0,0,0,0.035); }
        .nav-header .chevron { transition: transform 0.3s ease; font-size: 0.75rem; color: var(--text-muted); }
        .nav-group.expanded .nav-header .chevron { transform: rotate(180deg); color: var(--accent); }
        .nav-submenu { max-height: 0; overflow: hidden; transition: max-height 0.35s ease; display: flex; flex-direction: column; gap: 3px; padding-left: 14px; }
        .nav-group.expanded .nav-submenu { max-height: 600px; padding-top: 4px; padding-bottom: 4px; }

        /* --- MAIN CONTENT & TOPBAR --- */
        .main-wrapper { flex-grow: 1; display: flex; flex-direction: column; gap: 15px; overflow: hidden; width: 100%; }
        .topbar { display: flex; justify-content: space-between; align-items: center; padding: 14px 24px; border-radius: var(--radius-xl); }
        .user-info { display: flex; align-items: center; gap: 14px; }
        .role-badge { padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; background: rgba(0,0,0,0.05); color: var(--text-main); text-transform: uppercase; letter-spacing: 0.8px; }
        .notif-dot { position: absolute; top: 9px; right: 9px; width: 8px; height: 8px; background: var(--danger); border-radius: 50%; box-shadow: 0 0 0 2px #fff; }
        .notif-dropdown { position: absolute; top: 52px; right: 0; width: 350px; padding: 18px; max-height: 420px; overflow-y: auto; z-index: 100; display: none; opacity: 0; transform: translateY(-10px); transition: all 0.25s ease; border-radius: var(--radius-lg); }
        .notif-dropdown.show { display: block; opacity: 1; transform: translateY(0); }
        
        .main-content { flex-grow: 1; overflow-y: auto; padding-right: 6px; padding-bottom: 85px; }
        .main-content::-webkit-scrollbar { width: 6px; }
        .main-content::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.12); border-radius: 10px; }
        .view-section { display: none; animation: fadeIn 0.28s cubic-bezier(0.2, 0.8, 0.2, 1); }
        .view-section.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }

        .header-title { font-size: 1.55rem; font-weight: 800; margin-bottom: 16px; letter-spacing: -0.5px; display: flex; align-items: center; gap: 10px; }
        .table-container { width: 100%; overflow-x: auto; padding: 22px; margin-bottom: 20px; }
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; gap: 10px; flex-wrap: wrap; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { padding: 12px 14px; font-size: 0.82rem; color: var(--text-sub); border-bottom: 1px solid rgba(0,0,0,0.06); white-space: nowrap; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        td { padding: 14px; font-size: 0.92rem; border-bottom: 1px solid rgba(0,0,0,0.035); font-weight: 500; white-space: nowrap; color: var(--text-main); }
        tr:hover td { background: rgba(255,255,255,0.45); }
        .action-link { color: var(--accent); font-weight: 600; cursor: pointer; padding: 6px 13px; background: rgba(0, 122, 255, 0.09); border-radius: 8px; display: inline-block; transition: 0.2s; }
        .action-link:hover { background: rgba(0, 122, 255, 0.18); transform: translateY(-1px); }
        .row-disconnected { background-color: rgba(255, 59, 48, 0.03); }
        .row-isolated { background-color: rgba(255, 149, 0, 0.04); }

        /* --- DASHBOARD WIDGETS & CHARTS --- */
        .grid-hw { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .hw-card { padding: 20px; display: flex; flex-direction: column; gap: 8px; border-radius: var(--radius-lg); }
        .hw-title { font-size: 11px; color: var(--text-sub); font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; }
        .hw-val { font-size: 1.65rem; font-weight: 800; color: var(--text-main); font-variant-numeric: tabular-nums; }
        .progress-bg { width: 100%; height: 7px; background: rgba(0,0,0,0.06); border-radius: 4px; overflow: hidden; margin-top: 5px; }
        .progress-bar { height: 100%; border-radius: 4px; transition: width 0.5s ease; }
        .chart-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 20px; }
        .chart-box { padding: 18px 22px; border-radius: var(--radius-lg); }
        .chart-canvas-wrap { position: relative; height: 140px; width: 100%; }

        /* --- PIN KEYPAD & MORPH ANIMATION --- */
        .pin-input-group { display: flex; gap: 12px; justify-content: center; margin: 22px 0; }
        .pin-box { width: 52px; height: 62px; font-size: 28px; text-align: center; border: 1px solid rgba(0,0,0,0.1); border-radius: 14px; background: rgba(255,255,255,0.9); outline: none; -webkit-text-security: disc; font-weight: 700; color: var(--text-main); pointer-events: none; transition: 0.2s; }
        .pin-box.active { border-color: var(--accent); box-shadow: 0 0 0 4px var(--accent-glow); }
        .pin-box.err { border-color: var(--danger); color: var(--danger); }
        .custom-keypad { display: grid; grid-template-columns: repeat(3, 1fr); gap: 11px; margin-bottom: 20px; }
        .key-btn { background: rgba(255,255,255,0.7); border: 1px solid rgba(0,0,0,0.05); border-radius: 14px; padding: 13px; font-size: 21px; font-weight: 600; color: var(--text-main); cursor: pointer; transition: all 0.12s; box-shadow: 0 2px 6px rgba(0,0,0,0.02); }
        .key-btn:active { background: rgba(0, 122, 255, 0.15); transform: scale(0.95); }

        .status-view { display: flex; flex-direction: column; align-items: center; text-align: center; padding: 15px 0; }
        .morph-wrapper { width: 75px; height: 75px; margin: 0 auto 15px; position: relative; }
        .morph-svg { width: 100%; height: 100%; }
        .track-circle { fill: none; stroke: rgba(0,0,0,0.05); stroke-width: 4; }
        .draw-circle { fill: none; stroke: var(--accent); stroke-width: 4; stroke-dasharray: 164; stroke-dashoffset: 164; transform-origin: center; transform: rotate(-90deg); transition: stroke-dashoffset 0.4s ease, stroke 0.4s ease; }
        .check-line { fill: none; stroke: var(--success); stroke-width: 4; stroke-linecap: round; stroke-linejoin: round; stroke-dasharray: 50; stroke-dashoffset: 50; transition: stroke-dashoffset 0.4s ease; }
        .cross-line { fill: none; stroke: var(--danger); stroke-width: 4; stroke-linecap: round; stroke-linejoin: round; stroke-dasharray: 50; stroke-dashoffset: 50; transition: stroke-dashoffset 0.4s ease; }
        .is-loading .draw-circle { animation: spinSvg 1s linear infinite; stroke-dashoffset: 60; }
        @keyframes spinSvg { 100% { transform: rotate(270deg); } }
        .is-success .draw-circle { stroke: var(--success); stroke-dashoffset: 0; transform: rotate(-90deg); animation: none; fill: transparent; }
        .is-success .check-line { stroke-dashoffset: 0; transition-delay: 0.1s; }
        .is-failed .draw-circle { stroke: var(--danger); stroke-dashoffset: 0; transform: rotate(-90deg); animation: none; fill: transparent; }
        .is-failed .cross-line { stroke-dashoffset: 0; transition-delay: 0.1s; }
        
        .form-grid { display: grid; grid-template-columns: 1fr; gap: 10px; margin: 15px 0; text-align: left; }
        .form-grid.two-cols { grid-template-columns: 1fr 1fr; }
        .form-label { font-size: 11px; font-weight: 700; color: var(--text-sub); margin-bottom: -8px; margin-left: 4px; display: block; text-transform: uppercase; letter-spacing: 0.5px; }
        .action-btn-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; margin-top: 20px; }

        /* --- FLOATING WIDGET (ADMIN) --- */
        #floating-widget { position: fixed; bottom: 20px; right: 20px; z-index: 2500; background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(28px) saturate(200%); border: 1px solid rgba(255, 255, 255, 0.95); box-shadow: var(--shadow-float); transition: all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1); overflow: hidden; display: flex; flex-direction: column; }
        #floating-widget.collapsed { width: 56px; height: 56px; border-radius: 28px; cursor: pointer; }
        #floating-widget.collapsed:hover { transform: scale(1.06); background: rgba(255, 255, 255, 0.95); }
        #floating-widget.expanded { width: 340px; height: auto; max-height: 85vh; border-radius: 22px; cursor: default; }
        .fw-header { display: none; padding: 13px 16px; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(0,0,0,0.05); cursor: grab; background: rgba(255,255,255,0.6); }
        #floating-widget.expanded .fw-header { display: flex; }
        .fw-title { font-size: 13px; font-weight: 700; color: var(--text-main); display: flex; align-items: center; gap: 8px; }
        .fw-live-dot { width: 8px; height: 8px; background: var(--success); border-radius: 50%; animation: pulseGreen 2s infinite; }
        @keyframes pulseGreen { 0% { box-shadow: 0 0 0 0 rgba(52,199,89, 0.5); } 70% { box-shadow: 0 0 0 6px rgba(52,199,89, 0); } 100% { box-shadow: 0 0 0 0 rgba(52,199,89, 0); } }
        .fw-btn-collapse { background: rgba(0,0,0,0.06); border: none; width: 26px; height: 26px; border-radius: 13px; font-size: 12px; cursor: pointer; transition: 0.2s; display: flex; justify-content: center; align-items: center; }
        .fw-icon-collapsed { position: absolute; inset: 0; display: flex; justify-content: center; align-items: center; font-size: 22px; transition: 0.3s; pointer-events: none; }
        #floating-widget.expanded .fw-icon-collapsed { opacity: 0; transform: scale(0.5); }
        .fw-notif-badge { position: absolute; top: 12px; right: 12px; width: 10px; height: 10px; background: var(--accent); border-radius: 50%; border: 2px solid #fff; }
        #floating-widget.expanded .fw-notif-badge { opacity: 0; }
        .fw-content { padding: 16px; display: none; flex-direction: column; gap: 14px; overflow-y: auto; max-height: calc(85vh - 50px); }
        #floating-widget.expanded .fw-content { display: flex; }
        .fw-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .fw-box { background: rgba(255,255,255,0.7); border: 1px solid rgba(255,255,255,0.9); padding: 12px; border-radius: 14px; }
        .fw-box-title { font-size: 10px; font-weight: 700; color: var(--text-sub); text-transform: uppercase; margin-bottom: 5px; }
        .fw-box-val { font-size: 18px; font-weight: 800; color: var(--text-main); }
        .fw-box-sub { font-size: 10px; font-weight: 600; margin-top: 2px; color: var(--text-sub); }
        .fw-status-item { display: flex; justify-content: space-between; align-items: center; font-size: 12px; padding: 6px 0; border-bottom: 1px dashed rgba(0,0,0,0.06); }
        .fw-status-item:last-child { border-bottom: none; }
        .fw-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; margin-right: 6px; }
        .fw-dot.green { background: var(--success); } .fw-dot.yellow { background: var(--warning); } .fw-dot.red { background: var(--danger); } .fw-dot.gray { background: var(--text-sub); }
        .fw-chart-wrap { height: 50px; width: 100%; position: relative; margin-top: 5px; }
        .fw-action-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 5px; }

        /* --- OWNER FLOATING WIDGET --- */
        #owner-widget { position: fixed; bottom: 95px; right: 20px; z-index: 2500; background: linear-gradient(135deg, rgba(255,149,0,0.95), rgba(255,110,0,0.95)); color: white; backdrop-filter: blur(25px); border: 1px solid rgba(255, 255, 255, 0.4); box-shadow: var(--shadow-float); border-radius: 22px; padding: 12px 18px; display: none; align-items: center; gap: 14px; cursor: pointer; transition: all 0.3s ease; }
        #owner-widget:hover { transform: translateY(-3px) scale(1.02); }
        .ow-icon { font-size: 22px; animation: pulseDi 2s infinite; }
        .ow-text { font-size: 11.5px; font-weight: 600; line-height: 1.35; }
        .ow-val { font-size: 16px; font-weight: 800; background: rgba(0,0,0,0.15); padding: 3px 8px; border-radius: 10px; }

        /* --- SYSTEM FREEZE OVERLAY --- */
        #freeze-overlay { position: fixed; inset: 0; background: rgba(255, 59, 48, 0.18); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); z-index: 8500; display: none; flex-direction: column; justify-content: center; align-items: center; text-align: center; }
        #freeze-overlay.show { display: flex; animation: fadeIn 0.4s ease; }
        .freeze-card { background: rgba(255, 255, 255, 0.92); border: 1px solid rgba(255, 59, 48, 0.3); padding: 40px 32px; border-radius: 24px; box-shadow: 0 25px 60px rgba(255, 59, 48, 0.18); max-width: 440px; width: 90%; }
        .freeze-icon { font-size: 55px; margin-bottom: 15px; animation: pulseDi 2s infinite; }

        /* --- CODE & TERMINAL PREVIEWS --- */
        .code-preview { background: #0f172a; color: #38bdf8; padding: 16px; border-radius: 14px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 12px; overflow-x: auto; margin-bottom: 15px; line-height: 1.6; border: 1px solid rgba(255,255,255,0.08); box-shadow: inset 0 2px 8px rgba(0,0,0,0.3); }

        /* --- THERMAL VOUCHER PRINT TEMPLATE --- */
        .voucher-grid-print { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 15px; margin-top: 20px; }
        .voucher-card {
            background: #ffffff;
            border: 2px dashed #007aff;
            border-radius: 12px;
            padding: 16px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.04);
            position: relative;
        }
        .voucher-header { font-size: 14px; font-weight: 800; color: #007aff; margin-bottom: 4px; }
        .voucher-sub { font-size: 10px; color: #8e8e93; font-weight: 600; text-transform: uppercase; margin-bottom: 10px; }
        .voucher-code-box { background: #f0f4fc; border-radius: 8px; padding: 8px 10px; margin: 10px 0; font-family: monospace; font-size: 16px; font-weight: 800; letter-spacing: 1px; color: #1c1c1e; }
        .voucher-footer { font-size: 10px; color: #636366; margin-top: 8px; line-height: 1.4; }

        @media print {
            body * { visibility: hidden; }
            #print-area, #print-area * { visibility: visible; }
            #print-area { position: absolute; left: 0; top: 0; width: 100%; }
            .voucher-card { page-break-inside: avoid; border: 1px solid #000; }
        }

        /* --- RESPONSIVE SIDEBAR --- */
        .sidebar-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.4); backdrop-filter: blur(5px); z-index: 2000; opacity: 0; visibility: hidden; transition: all 0.3s ease; }
        .sidebar-overlay.show { opacity: 1; visibility: visible; }
        .sidebar { position: fixed; left: -300px; top: 0; height: 100vh; width: 265px; padding: 20px 16px; display: flex; flex-direction: column; gap: 5px; overflow-y: auto; z-index: 2010; margin: 0; border-radius: 0; transition: left 0.35s cubic-bezier(0.4, 0, 0.2, 1); box-shadow: 12px 0 40px rgba(0,0,0,0.1); }
        .sidebar::-webkit-scrollbar { display: none; }
        .sidebar.show { left: 0; }
        .btn-menu { background: var(--accent); color: white; border: none; padding: 8px 13px; border-radius: 11px; cursor: pointer; font-size: 15px; transition: 0.2s; display: flex; align-items: center; justify-content: center; }
        .btn-menu:active { transform: scale(0.95); }

        @media (max-width: 900px) {
            .grid-hw { grid-template-columns: repeat(2, 1fr); }
            .chart-grid { grid-template-columns: 1fr; }
            #app-layout { padding: 12px 6px; }
            #floating-widget.expanded { width: calc(100% - 30px); right: 15px; bottom: 15px; }
            #owner-widget { bottom: 85px; right: 15px; }
        }
        @media (max-width: 480px) {
            .grid-hw { grid-template-columns: 1fr; }
            .user-info #display-user-wrap { display: none; }
            .toolbar { flex-direction: column; align-items: stretch; }
            .toolbar input, .toolbar select, .toolbar button { width: 100% !important; margin-bottom: 6px; }
            .form-grid.two-cols { grid-template-columns: 1fr; }
            .greet-grid, .greet-summary { grid-template-columns: 1fr; }
            #dynamic-island.active { min-width: 190px; padding: 0 14px; }
            #dynamic-island.active.expand { min-width: 230px; }
        }
    </style>
</head>
<body>
    <div class="liquid-bg">
        <div class="orb orb-1"></div>
        <div class="orb orb-2"></div>
        <div class="orb orb-3"></div>
    </div>

    <!-- SPLASH SCREEN (JAVAICA TYPING ANIMATION) -->
    <div id="splash-screen">
        <h1 class="splash-logo" id="splash-logo"></h1>
        <div class="splash-sub" id="splash-sub">RADIUS SERVER &bull; POWERED BY JAVAICA</div>
    </div>

    <!-- SYSTEM FREEZE OVERLAY (LOCKDOWN MODE) -->
    <div id="freeze-overlay">
        <div class="freeze-card">
            <div class="freeze-icon">🔒</div>
            <h1 style="color: var(--danger); margin-bottom: 10px; font-size: 1.6rem;">SYSTEM LOCKED</h1>
            <p style="font-size: 14px; font-weight: 600; color: var(--text-main); margin-bottom: 16px;">Seluruh sistem sedang dikunci oleh Owner.</p>
            <p style="font-size: 13px; color: var(--text-sub); margin-bottom: 20px;">Akses Write, Edit, dan Delete dinonaktifkan sementara demi keamanan konfigurasi.</p>
            
            <div style="background: rgba(0,0,0,0.035); padding: 16px; border-radius: 14px; text-align: left; font-size: 12.5px; border: 1px solid rgba(0,0,0,0.05);">
                <div style="display:flex; justify-content:space-between; margin-bottom:6px;"><span style="color:var(--text-sub); font-weight:600;">Status</span><span style="font-weight:700; color:var(--danger);">Maintenance Mode Active</span></div>
                <div style="display:flex; justify-content:space-between; margin-bottom:6px;"><span style="color:var(--text-sub); font-weight:600;">Kunci Oleh</span><span style="font-weight:700;" id="freeze-owner-name">Ruben (Owner)</span></div>
                <div style="display:flex; justify-content:space-between; margin-bottom:6px;"><span style="color:var(--text-sub); font-weight:600;">Alasan</span><span style="font-weight:700;" id="freeze-reason-text">Pembaruan RADIUS & Database</span></div>
                <div style="display:flex; justify-content:space-between;"><span style="color:var(--text-sub); font-weight:600;">Estimasi Selesai</span><span style="font-weight:700;" id="freeze-est-text">60 Menit</span></div>
            </div>
            
            <button class="btn-ios btn-outline" style="width: 100%; margin-top: 20px;" onclick="document.getElementById('freeze-overlay').classList.remove('show'); alert('Anda beralih ke Mode Read-Only.');">Lanjutkan Read-Only</button>
        </div>
    </div>

    <!-- 0. LOGIN SCREEN -->
    <div id="login-screen">
        <div class="glass-panel login-card">
            <div style="display: flex; justify-content: center; margin-bottom: 12px;">
                <div style="width: 54px; height: 54px; border-radius: 16px; background: linear-gradient(135deg, #007aff, #5856d6); display: flex; align-items: center; justify-content: center; color: white; font-size: 26px; box-shadow: 0 8px 20px var(--accent-glow);">
                    ⚡
                </div>
            </div>
            <h2 style="font-weight: 800; letter-spacing: -0.5px; margin-bottom: 4px;">RADIUS Control Center</h2>
            <div style="margin-bottom: 24px; color: var(--text-sub); font-size: 13.5px; font-weight: 500;">Masuk untuk mengelola MikroTik & RADIUS</div>
            
            <input type="text" class="input-ios" placeholder="Username" id="login-user" value="super_admin">
            <input type="password" class="input-ios" placeholder="Password" id="login-pass" value="1234">
            
            <button class="btn-ios" style="width: 100%; font-size: 14.5px; padding: 14px; margin-top: 8px;" onclick="startChecklistFlow()">Masuk Sistem</button>
            <p style="font-size: 11px; color: var(--text-muted); margin-top: 18px; font-weight: 600;">Cloudflare Workers &bull; Supabase PostgreSQL</p>
        </div>
    </div>

    <!-- 1. MORNING CHECKLIST SCREEN -->
    <div id="checklist-screen" style="display: none;">
        <div class="glass-panel login-card" style="max-width: 440px; text-align: center;">
            <h2 style="margin-bottom: 4px; font-weight: 800;">Morning System Checklist</h2>
            <p style="font-size: 13px; color: var(--text-sub); margin-bottom: 18px;">Pemeriksaan kesehatan layanan & konektivitas RADIUS...</p>
            <div style="display: flex; justify-content: space-between; font-size: 11px; font-weight: 700; color: var(--accent); margin-bottom: 6px;"><span id="chk-prog-text">Pemeriksaan...</span><span id="chk-prog-pct">0%</span></div>
            <div class="progress-bg" style="margin-bottom: 16px;"><div class="progress-bar" id="chk-bar" style="width: 0%; background: var(--accent);"></div></div>
            <ul class="chk-list" id="chk-container"></ul>
            <div id="chk-final-msg" style="font-weight: 700; font-size: 14.5px; margin-top: 14px; opacity: 0; transition: 0.3s;"></div>
        </div>
    </div>

    <!-- 2. ADMIN PIN LOGIN SCREEN -->
    <div id="login-pin-screen" style="display: none;">
        <div class="glass-panel login-card" id="login-pin-box" style="max-width: 360px;">
            <h2 style="margin-bottom: 4px; font-weight: 800;">Verifikasi PIN</h2>
            <p style="font-size: 13px; color: var(--text-sub); font-weight: 500;">Masukkan 4 digit PIN Administrator.</p>
            <p style="font-size: 11px; color: var(--accent); margin-top: 4px; font-weight: 600;">(PIN Default = 1234)</p>
            <div class="pin-input-group" id="login-pin-group">
                <input type="password" class="pin-box" id="lpin1" readonly tabindex="-1"><input type="password" class="pin-box" id="lpin2" readonly tabindex="-1">
                <input type="password" class="pin-box" id="lpin3" readonly tabindex="-1"><input type="password" class="pin-box" id="lpin4" readonly tabindex="-1">
            </div>
            <div class="custom-keypad">
                <button class="key-btn" onclick="pressLoginPin(1)">1</button><button class="key-btn" onclick="pressLoginPin(2)">2</button><button class="key-btn" onclick="pressLoginPin(3)">3</button>
                <button class="key-btn" onclick="pressLoginPin(4)">4</button><button class="key-btn" onclick="pressLoginPin(5)">5</button><button class="key-btn" onclick="pressLoginPin(6)">6</button>
                <button class="key-btn" onclick="pressLoginPin(7)">7</button><button class="key-btn" onclick="pressLoginPin(8)">8</button><button class="key-btn" onclick="pressLoginPin(9)">9</button>
                <button class="key-btn key-action" onclick="clearLoginPin()">C</button><button class="key-btn" onclick="pressLoginPin(0)">0</button><button class="key-btn key-action" onclick="deleteLoginPin()">⌫</button>
            </div>
            <p id="login-pin-error" style="color: var(--danger); font-size: 12.5px; font-weight: 700; opacity: 0; transition: 0.2s;">PIN yang Anda masukkan salah!</p>
        </div>
    </div>

    <!-- 3. SMART GREETING SCREEN -->
    <div id="greeting-screen" style="display: none;">
        <div class="glass-panel greet-box" id="greet-box">
            <h1 style="font-size: 1.75rem; margin-bottom: 4px; color: var(--text-main); font-weight: 800;" id="greet-header">Selamat Pagi, Ruben 👋</h1>
            <p style="font-size: 13.5px; color: var(--text-sub); margin-bottom: 20px;">Berikut status jaringan & RADIUS ISP Anda:</p>
            <div class="greet-grid">
                <div class="greet-item"><span class="fw-dot green"></span> PPPoE Aktif: <b id="greet-pppoe-count">82</b></div>
                <div class="greet-item"><span class="fw-dot red"></span> Client Isolir: <b id="greet-isolir-count">1</b></div>
                <div class="greet-item"><span class="fw-dot green"></span> Hotspot Aktif: <b id="greet-hotspot-count">45</b></div>
                <div class="greet-item"><span class="fw-dot yellow"></span> Request Tiket: <b id="greet-ticket-count">2</b></div>
                <div class="greet-item"><span class="fw-dot green"></span> RADIUS Server: <b>Online</b></div>
                <div class="greet-item"><span class="fw-dot green"></span> Supabase DB: <b>Connected</b></div>
                <div class="greet-item"><span class="fw-dot green"></span> WhatsApp Gateway: <b>Online</b></div>
                <div class="greet-item"><span class="fw-dot green"></span> Telegram Bot: <b>Online</b></div>
            </div>
            <div style="text-align: left; margin-bottom: 8px; font-size: 12.5px; font-weight: 700;">Ringkasan Operasional</div>
            <div class="greet-summary">
                <div class="greet-sum-card"><div style="font-size:10px; color:var(--text-sub); font-weight:700; text-transform:uppercase;">Pendapatan Bulan Ini</div><div style="font-size:16px; font-weight:800; color:var(--success);" id="greet-income">Rp 850.000</div><div style="font-size:11px; color:var(--danger); margin-top:3px;" id="greet-unpaid">1 Belum Bayar</div></div>
                <div class="greet-sum-card"><div style="font-size:10px; color:var(--text-sub); font-weight:700; text-transform:uppercase;">Traffic WAN Terpantau</div><div style="font-size:16px; font-weight:800; color:var(--accent);" id="greet-traffic">230 Mbps</div><div style="font-size:11px; color:var(--text-main); margin-top:3px;" id="greet-clients">Total: 6 Client</div></div>
            </div>
            <div style="font-style: italic; color: var(--text-sub); font-size: 12.5px; margin-bottom: 20px;" id="greet-quote">"Semoga jaringan hari ini berjalan lancar."</div>
            <div id="greet-countdown" style="width: 100%; padding: 13px; font-size: 13.5px; font-weight: 700; color: var(--accent); background: rgba(0, 122, 255, 0.1); border-radius: var(--radius-md); border: 1px solid rgba(0, 122, 255, 0.25);">Memasuki dasbor dalam 3 detik...</div>
        </div>
    </div>

    <!-- 4. MAIN APP LAYOUT (DASHBOARD) -->
    <div id="app-layout">
        <!-- Mobile Sidebar Overlay -->
        <div class="sidebar-overlay" id="sidebar-overlay" onclick="toggleSidebar()"></div>
        
        <!-- SIDEBAR -->
        <nav class="glass-panel sidebar">
            <div class="brand">
                <span>_uvwxyz</span>
                <span class="brand-badge">RADIUS PRO</span>
            </div>
            
            <div class="nav-item active" onclick="switchView('view-dasbor', this, true)">
                <span>⚡ Dasbor Utama</span>
            </div>
            
            <!-- RADIUS MANAGEMENT GROUP -->
            <div class="nav-group expanded">
                <div class="nav-header" onclick="toggleSubmenu(this)"><span style="color:var(--accent);">📡 RADIUS Server</span> <span class="chevron">▼</span></div>
                <div class="nav-submenu">
                    <div class="nav-item" onclick="switchView('view-radius-sessions', this)">Sesi Aktif (Radacct)</div>
                    <div class="nav-item" onclick="switchView('view-vouchers', this)" style="color:var(--purple); font-weight:600;">Cetak Voucher Hotspot</div>
                    <div class="nav-item" onclick="switchView('view-mikrotik-config', this)">MikroTik Setup Script</div>
                </div>
            </div>

            <!-- PPPoE -->
            <div class="nav-group">
                <div class="nav-header" onclick="toggleSubmenu(this)"><span>🔌 PPPoE</span> <span class="chevron">▼</span></div>
                <div class="nav-submenu">
                    <div class="nav-item" onclick="switchView('view-pppoe-client', this)">PPPoE Client (RADIUS)</div>
                    <div class="nav-item" onclick="switchView('view-pppoe-manage', this)">Profil Paket PPPoE</div>
                </div>
            </div>

            <!-- HOTSPOT -->
            <div class="nav-group">
                <div class="nav-header" onclick="toggleSubmenu(this)"><span>📶 Hotspot</span> <span class="chevron">▼</span></div>
                <div class="nav-submenu">
                    <div class="nav-item" onclick="switchView('view-hotspot-client', this)">Hotspot Client</div>
                    <div class="nav-item" onclick="switchView('view-hotspot-manage', this)">Profil Paket Hotspot</div>
                </div>
            </div>

            <!-- ISOLIR & TRAFFIC -->
            <div class="nav-item" onclick="switchView('view-isolir', this, true)" style="color: var(--danger);">
                <span>🚫 Isolir Terpadu</span>
            </div>
            <div class="nav-item" onclick="switchView('view-traffic-shaper', this, true)" style="color: var(--accent);">
                <span>🎛️ Bandwidth Matrix</span>
            </div>
            <div class="nav-item" onclick="switchView('view-report', this, true)" style="color: var(--success);">
                <span>📊 Laporan & Keuangan</span>
            </div>
            
            <!-- CLIENT REQUESTS / TICKETS -->
            <div class="nav-group">
                <div class="nav-header" onclick="toggleSubmenu(this)"><span>🎫 Tiket & Request</span> <span class="chevron">▼</span></div>
                <div class="nav-submenu">
                    <div class="nav-item" onclick="switchView('view-ticket-kendala', this)">Tiket Kendala</div>
                    <div class="nav-item" onclick="switchView('view-ticket-pppoe', this)">Request Pasang Baru</div>
                </div>
            </div>

            <!-- NETWORK TOOLS -->
            <div class="nav-group">
                <div class="nav-header" onclick="toggleSubmenu(this)"><span>🛠️ Alat Jaringan</span> <span class="chevron">▼</span></div>
                <div class="nav-submenu">
                    <div class="nav-item" onclick="switchView('view-speedtest', this)">Speedtest (BwTest)</div>
                    <div class="nav-item" onclick="switchView('view-ping', this)">Ping & Traceroute</div>
                </div>
            </div>

            <!-- SYSTEM SETTINGS -->
            <div class="nav-group">
                <div class="nav-header" onclick="toggleSubmenu(this)"><span>⚙️ Sistem & Integrasi</span> <span class="chevron">▼</span></div>
                <div class="nav-submenu">
                    <div class="nav-item" onclick="switchView('view-system-mikrotik', this)">MikroTik API</div>
                    <div class="nav-item" onclick="switchView('view-system-telegram', this)">Telegram Bot</div>
                    <div class="nav-item" onclick="switchView('view-system-wa', this)" style="color: var(--success);">WhatsApp Gateway</div>
                    <div class="nav-item" id="menu-system-audit" onclick="switchView('view-system-audit', this)" style="display: none; color: var(--danger);">Audit Trail Log</div>
                </div>
            </div>

            <!-- OWNER SECTION -->
            <div class="nav-group" id="menu-owner-group" style="display: none; margin-top: 8px; border-top: 1px solid rgba(0,0,0,0.06); padding-top: 8px;">
                <div class="nav-header" onclick="toggleSubmenu(this)"><span style="color:var(--warning);">👑 Owner Console</span> <span class="chevron">▼</span></div>
                <div class="nav-submenu">
                    <div class="nav-item" id="nav-approval-center" onclick="switchView('view-approval-center', this)" style="color: var(--warning); font-weight: 700;">Approval Center</div>
                    <div class="nav-item" onclick="openSystemFreezeModal()" style="color: var(--danger); font-weight: 700;">System Freeze</div>
                    <div class="nav-item" onclick="switchView('view-admin-report', this)">Laporan Admin Harian</div>
                    <div class="nav-item" onclick="switchView('view-role-manage', this)">Manajemen Kredensial</div>
                </div>
            </div>

            <div class="nav-item" onclick="initiateLogout()" style="color: var(--danger); font-weight: 700; margin-top: 12px;">
                <span>🔴 Keluar (Logout)</span>
            </div>
        </nav>

        <!-- MAIN VIEWPORT -->
        <div class="main-wrapper">
            <header class="glass-panel topbar">
                <div style="display: flex; align-items: center; gap: 14px;">
                    <button class="btn-menu" onclick="toggleSidebar()">☰</button>
                    <div style="font-size: 1.25rem; font-weight: 800; letter-spacing: -0.4px;" id="topbar-title">Dasbor Utama</div>
                </div>
                <div class="user-info">
                    <div class="role-badge" id="display-role">ROLE</div>
                    <div id="display-user-wrap" style="font-size: 13.5px; font-weight: 600; cursor: pointer;" onclick="openMyProfile()">
                        Halo, <span id="display-user">User</span>
                        <span style="font-size:10px; color:var(--accent); margin-left:4px; font-weight: 700;">(Profil)</span>
                    </div>
                    
                    <!-- DYNAMIC ISLAND v2 -->
                    <div style="position: relative;">
                        <div id="dynamic-island" onclick="handleIslandClick()">
                            <div class="di-bell">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                                <div class="notif-dot" id="notif-dot" style="display: none;"></div>
                            </div>
                            <div class="di-content-wrapper">
                                <div class="di-icon" id="di-icon">⏳</div>
                                <div id="di-text">RADIUS Ready</div>
                            </div>
                        </div>
                        <div class="glass-panel notif-dropdown" id="notif-panel">
                            <div style="font-size: 11px; font-weight: 800; color: var(--text-sub); margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid rgba(0,0,0,0.06); text-transform: uppercase;">NOTIFIKASI SISTEM</div>
                            <div id="notif-list" style="font-size: 12.5px; color: var(--text-sub);">Belum ada notifikasi baru.</div>
                        </div>
                    </div>
                </div>
            </header>

            <main class="main-content">
                <!-- VIEW 1: DASBOR -->
                <section id="view-dasbor" class="view-section active">
                    <h1 class="header-title">Status Jaringan & Hardware MikroTik</h1>
                    <div class="grid-hw">
                        <div class="glass-panel hw-card">
                            <span class="hw-title">CPU Load</span>
                            <span class="hw-val" id="live-cpu-val">--%</span>
                            <div class="progress-bg"><div class="progress-bar" id="live-cpu-bar" style="width: 0%; background: var(--success);"></div></div>
                        </div>
                        <div class="glass-panel hw-card">
                            <span class="hw-title">Free Memory</span>
                            <span class="hw-val" id="live-mem-val">-- MB <span style="font-size:12px; color:var(--text-sub); font-weight:500;">/ -- MB</span></span>
                            <div class="progress-bg"><div class="progress-bar" id="live-mem-bar" style="width: 0%; background: var(--accent);"></div></div>
                        </div>
                        <div class="glass-panel hw-card">
                            <span class="hw-title">Disk Storage</span>
                            <span class="hw-val" id="live-disk-val">--%</span>
                            <div class="progress-bg"><div class="progress-bar" id="live-disk-bar" style="width: 0%; background: var(--success);"></div></div>
                        </div>
                        <div class="glass-panel hw-card">
                            <span class="hw-title">System Uptime</span>
                            <span class="hw-val" style="font-size: 1.25rem; padding-top: 4px;" id="live-uptime">--</span>
                            <span style="font-size: 11px; color: var(--text-sub); margin-top:4px; font-weight: 600;" id="live-board">Core-CCR1036 (RouterOS v7)</span>
                        </div>
                    </div>

                    <div class="chart-grid">
                        <div class="glass-panel chart-box">
                            <div class="toolbar" style="margin-bottom: 6px; flex-direction: column; align-items: flex-start; gap: 4px;">
                                <span class="hw-title">Traffic: Ether WAN (ISP Utama)</span>
                                <div style="display:flex; justify-content:space-between; width:100%; font-size:11px; font-weight:700;">
                                    <span style="color: var(--accent);">DL: <span id="wan-dl">--</span> | <span style="color: var(--success);">UL: <span id="wan-ul">--</span></span></span>
                                    <span style="color: var(--warning);">Total: <span id="wan-total">--</span></span>
                                </div>
                            </div>
                            <div class="chart-canvas-wrap"><canvas id="chartWan"></canvas></div>
                        </div>
                        <div class="glass-panel chart-box">
                            <div class="toolbar" style="margin-bottom: 6px; flex-direction: column; align-items: flex-start; gap: 4px;">
                                <span class="hw-title">Traffic: PPPoE Client</span>
                                <div style="display:flex; justify-content:space-between; width:100%; font-size:11px; font-weight:700;">
                                    <span style="color: var(--accent);">DL: <span id="pppoe-dl">--</span> | <span style="color: var(--success);">UL: <span id="pppoe-ul">--</span></span></span>
                                    <span style="color: var(--warning);">Total: <span id="pppoe-total">--</span></span>
                                </div>
                            </div>
                            <div class="chart-canvas-wrap"><canvas id="chartPppoe"></canvas></div>
                        </div>
                        <div class="glass-panel chart-box">
                            <div class="toolbar" style="margin-bottom: 6px; flex-direction: column; align-items: flex-start; gap: 4px;">
                                <span class="hw-title">Traffic: Hotspot Shared</span>
                                <div style="display:flex; justify-content:space-between; width:100%; font-size:11px; font-weight:700;">
                                    <span style="color: var(--accent);">DL: <span id="hs-dl">--</span> | <span style="color: var(--success);">UL: <span id="hs-ul">--</span></span></span>
                                    <span style="color: var(--warning);">Total: <span id="hs-total">--</span></span>
                                </div>
                            </div>
                            <div class="chart-canvas-wrap"><canvas id="chartHotspot"></canvas></div>
                        </div>
                        <div class="glass-panel chart-box">
                            <div class="toolbar" style="margin-bottom: 6px; flex-direction: column; align-items: flex-start; gap: 4px;">
                                <span class="hw-title">Traffic: Admin / Local LAN</span>
                                <div style="display:flex; justify-content:space-between; width:100%; font-size:11px; font-weight:700;">
                                    <span style="color: var(--accent);">DL: <span id="adm-dl">--</span> | <span style="color: var(--success);">UL: <span id="adm-ul">--</span></span></span>
                                    <span style="color: var(--warning);">Total: <span id="adm-total">--</span></span>
                                </div>
                            </div>
                            <div class="chart-canvas-wrap"><canvas id="chartAdmin"></canvas></div>
                        </div>
                    </div>
                </section>

                <!-- VIEW 2: RADIUS ACCOUNTING SESSIONS (Radacct) -->
                <section id="view-radius-sessions" class="view-section">
                    <h1 class="header-title">📡 RADIUS Active Accounting Sessions</h1>
                    <p style="font-size: 13px; color: var(--text-sub); margin-bottom: 18px;">Data sesi aktif real-time dari tabel RADIUS (Radacct) dengan dukungan Disconnect / CoA.</p>
                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <input type="text" class="input-ios" placeholder="Cari sesi username/IP/MAC..." style="width: 280px; margin:0;">
                            <button class="btn-ios btn-outline" onclick="fetchRadiusSessions()">🔄 Refresh Sesi</button>
                        </div>
                        <table id="tbl-radius-sessions">
                            <thead><tr><th>Session ID</th><th>Username</th><th>Framed IP</th><th>Calling Station (MAC)</th><th>Uptime</th><th>Data (DL/UL)</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-radius-sessions">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 3: HOTSPOT VOUCHER BATCH GENERATOR & THERMAL PRINT -->
                <section id="view-vouchers" class="view-section">
                    <h1 class="header-title">🎫 Hotspot Voucher Generator & Cetak</h1>
                    <div class="grid-hw" style="grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                        <div class="glass-panel" style="padding: 24px;">
                            <h3 style="margin-bottom: 14px; font-size: 16px;">Generate Batch Voucher Baru</h3>
                            <div class="form-grid" style="margin:0;">
                                <span class="form-label">Jumlah Voucher</span>
                                <select id="v_count" class="input-ios">
                                    <option value="5">5 Lembar</option>
                                    <option value="10" selected>10 Lembar</option>
                                    <option value="25">25 Lembar</option>
                                    <option value="50">50 Lembar</option>
                                </select>
                                <span class="form-label">Paket Hotspot</span>
                                <select id="v_pkg" class="input-ios">
                                    <option value="Voucher 5 Jam">Voucher 5 Jam (5M/2M) - Rp 5.000</option>
                                    <option value="Hotspot VIP">Hotspot VIP (20M/10M) - Rp 20.000</option>
                                </select>
                                <span class="form-label">Prefix Kode</span>
                                <input type="text" id="v_prefix" class="input-ios" value="WIFI" placeholder="Contoh: WIFI">
                                <span class="form-label">Harga Satuan (Rp)</span>
                                <input type="number" id="v_price" class="input-ios" value="5000">
                            </div>
                            <button class="btn-ios" style="width: 100%; margin-top: 14px;" onclick="generateVouchers()">⚡ Generate Voucher RADIUS</button>
                        </div>

                        <div class="glass-panel" style="padding: 24px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                            <div style="font-size: 42px; margin-bottom: 10px;">🖨️</div>
                            <h3 style="margin-bottom: 8px;">Cetak Struk & Kartu Thermal</h3>
                            <p style="font-size: 12.5px; color: var(--text-sub); max-width: 320px; margin-bottom: 18px;">Format cetak siap pakai dengan QR Code, SSID Wi-Fi, username, dan password untuk printer thermal POS.</p>
                            <button class="btn-ios btn-purple" onclick="openPrintVoucherModal()">📄 Pratinjau & Cetak Voucher</button>
                        </div>
                    </div>

                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <h3 style="font-size: 15px; margin: 0;">Daftar Voucher Tersedia</h3>
                            <input type="text" class="input-ios" placeholder="Cari kode voucher..." style="width: 240px; margin:0;">
                        </div>
                        <table id="tbl-vouchers">
                            <thead><tr><th>Kode Voucher</th><th>Password</th><th>Paket</th><th>Harga</th><th>Status</th><th>Batch</th><th>Tanggal</th></tr></thead>
                            <tbody id="tbody-vouchers">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 4: MIKROTIK RADIUS SETUP SCRIPT -->
                <section id="view-mikrotik-config" class="view-section">
                    <h1 class="header-title">⚙️ MikroTik RouterOS v7 RADIUS Setup</h1>
                    <div class="glass-panel" style="padding: 26px;">
                        <p style="font-size: 13.5px; color: var(--text-sub); margin-bottom: 20px;">Salin dan tempel skrip berikut ke terminal MikroTik RouterOS Anda untuk mengaktifkan AAA RADIUS terpadu.</p>
                        
                        <div class="code-preview" id="mikrotik-script-box">
# === MIKROTIK ROUTEROS v7 RADIUS CONFIGURATION ===
# Dibuat otomatis oleh MikroTik RADIUS Control Center

/radius add address=127.0.0.1 secret=radsec123 service=hotspot,pppoe comment="Supabase Cloud RADIUS" timeout=3000ms
/radius incoming set accept=yes port=3799

# Konfigurasi Server PPPoE untuk menggunakan RADIUS
/interface pppoe-server server set [find] use-radius=yes authentication=pap,chap,mschap2

# Konfigurasi Server Hotspot untuk menggunakan RADIUS
/ip hotspot profile set [find] use-radius=yes

# Buat Pool Isolir untuk Pengguna Menunggak
/ip pool add name=pool-isolir ranges=192.168.99.2-192.168.99.254
/ip firewall nat add chain=srcnat action=masquerade src-address=192.168.99.0/24 comment="NAT Isolir"
/ip firewall nat add chain=dstnat protocol=tcp dst-port=80 src-address=192.168.99.0/24 action=redirect to-ports=8080 comment="Redirect Web Isolir"
                        </div>
                        
                        <button class="btn-ios" onclick="copyMikrotikScript()">📋 Salin Skrip ke Clipboard</button>
                    </div>
                </section>

                <!-- VIEW 5: PPPOE CLIENT & PROFILES -->
                <section id="view-pppoe-client" class="view-section">
                    <h1 class="header-title">PPPoE Client (RADIUS Database)</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <input type="text" class="input-ios" placeholder="Cari user/IP..." style="width: 280px; margin:0;">
                            <button class="btn-ios" onclick="openFormModal('pppoe_client')">+ Tambah PPPoE Client</button>
                        </div>
                        <table id="tbl-pppoe-client">
                            <thead><tr><th>User</th><th>IP Address</th><th>Status</th><th>Traffic (DL/UL)</th><th>Device</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-pppoe-client">
                                <!-- Populated by JS -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <section id="view-pppoe-manage" class="view-section">
                    <h1 class="header-title">Manajemen Paket & Profil PPPoE</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <button class="btn-ios" onclick="openFormModal('pppoe_profile')">+ Tambah Profil Paket</button>
                        </div>
                        <table id="tbl-pppoe-profile">
                            <thead><tr><th>Nama Paket</th><th>Local Address</th><th>Remote Pool</th><th>Rate Limit (Mikrotik-Rate-Limit)</th><th>Harga</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-pppoe-profile">
                                <!-- Populated by JS -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 6: HOTSPOT CLIENT & PROFILES -->
                <section id="view-hotspot-client" class="view-section">
                    <h1 class="header-title">Hotspot Client (RADIUS Database)</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <input type="text" class="input-ios" placeholder="Cari user/IP..." style="width: 280px; margin:0;">
                            <button class="btn-ios" onclick="openFormModal('hotspot_client')">+ Tambah Hotspot Client</button>
                        </div>
                        <table id="tbl-hotspot-client">
                            <thead><tr><th>User</th><th>IP Address</th><th>Status</th><th>Traffic (DL/UL)</th><th>Device</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-hotspot-client">
                                <!-- Populated by JS -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <section id="view-hotspot-manage" class="view-section">
                    <h1 class="header-title">Manajemen Profil Hotspot</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <button class="btn-ios" onclick="openFormModal('hotspot_profile')">+ Tambah Profil Hotspot</button>
                        </div>
                        <table id="tbl-hotspot-profile">
                            <thead><tr><th>Nama Profil</th><th>Shared Users</th><th>Rate Limit (DL/UL)</th><th>Harga</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-hotspot-profile">
                                <!-- Populated by JS -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 7: ISOLIR TERPADU -->
                <section id="view-isolir" class="view-section">
                    <h1 class="header-title" style="color: var(--danger);">Isolir Terpadu Pelanggan</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <div style="display:flex; gap:12px; flex-wrap: wrap;">
                                <button class="btn-ios btn-danger" onclick="triggerAction('Configuration', 'Eksekusi Massal Isolir Tagihan', 'Mass Isolir Selesai', 'Seluruh client menunggak dialihkan ke pool-isolir & 128k/128k.')">⚡ Mass Isolir Tagihan</button>
                                <button class="btn-ios btn-warning" onclick="triggerAction('Configuration', 'Eksekusi Massal Isolir Maintenance', 'Isolir Selesai', 'Client maintenance telah diisolir.')">Mass Isolir Maintenance</button>
                                <button class="btn-ios btn-success" onclick="restoreAllIsolated()">Un-Isolir Semua Client</button>
                            </div>
                        </div>
                        <table id="tbl-isolir-list">
                            <thead><tr><th>User</th><th>IP Address</th><th>MAC Address</th><th>Paket Asal</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-isolir-list">
                                <!-- Populated by JS -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 8: TRAFFIC SHAPER (BANDWIDTH MATRIX) -->
                <section id="view-traffic-shaper" class="view-section">
                    <h1 class="header-title">Visual Bandwidth Matrix & Queue Shaper</h1>
                    <div class="grid-hw" style="grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="glass-panel" style="padding: 26px;">
                            <h3>Alokasi Queue Tree / Simple Queue</h3>
                            <div style="margin-top: 20px;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; font-weight: 700;"><span>PPPoE VIP</span><span id="val-vip">400 Mbps</span></div>
                                <input type="range" style="width:100%; margin-bottom: 16px;" id="slider-vip" min="0" max="1000" step="10" value="400" oninput="updateShaperMatrix()">
                                
                                <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; font-weight: 700;"><span>PPPoE Regular</span><span id="val-reg">350 Mbps</span></div>
                                <input type="range" style="width:100%; margin-bottom: 16px;" id="slider-reg" min="0" max="1000" step="10" value="350" oninput="updateShaperMatrix()">
                                
                                <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; font-weight: 700;"><span>Hotspot Shared</span><span id="val-hot">150 Mbps</span></div>
                                <input type="range" style="width:100%; margin-bottom: 16px;" id="slider-hot" min="0" max="1000" step="10" value="150" oninput="updateShaperMatrix()">
                            </div>
                            <div style="margin-top: 22px; border-top: 1px solid rgba(0,0,0,0.08); padding-top: 15px; display: flex; justify-content: space-between; font-weight: 800; font-size: 15px;">
                                <span>Total Alokasi Bandwidth:</span>
                                <span id="shaper-total-text">900 Mbps</span>
                            </div>
                            <button id="btn-apply-shaper" class="btn-ios" style="width: 100%; margin-top: 20px;" onclick="triggerAction('Configuration', 'Matrix Bandwidth Diterapkan', 'Limitasi Aktif', 'Aturan queue tree dan limitasi paket berhasil disinkronkan ke MikroTik.')">Terapkan Limitasi ke RouterOS</button>
                        </div>
                        <div class="glass-panel" style="padding: 26px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <h3 style="margin-bottom: 20px;">Distribusi Matrix Bandwidth</h3>
                            <div style="position: relative; width: 100%; height: 240px; max-width: 240px;">
                                <canvas id="shaperDonut"></canvas>
                                <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; pointer-events: none;">
                                    <div style="font-size: 11px; font-weight: 700; color: var(--text-sub);">Sisa Headroom</div>
                                    <div id="donut-idle-text" style="font-size: 24px; font-weight: 800; color: var(--text-main);">100M</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- VIEW 9: LAPORAN & KEUANGAN -->
                <section id="view-report" class="view-section">
                    <h1 class="header-title">Laporan Keuangan & Analisis Trafik</h1>
                    <div class="toolbar glass-panel" style="padding: 14px 20px; border-radius: 16px; margin-bottom: 20px; justify-content: flex-start; gap: 10px;">
                        <button class="btn-ios report-tab" id="tab-harian" onclick="changeReportTab('harian', this)">Harian</button>
                        <button class="btn-ios btn-outline report-tab" id="tab-mingguan" onclick="changeReportTab('mingguan', this)">Mingguan</button>
                        <button class="btn-ios btn-outline report-tab" id="tab-bulanan" onclick="changeReportTab('bulanan', this)">Bulanan</button>
                        <button class="btn-ios btn-outline report-tab" id="tab-custom" onclick="changeReportTab('custom', this)">Custom Date</button>
                        <div id="report-custom-date" style="display: none; align-items: center; gap: 10px; margin-left: auto; flex-wrap: wrap;">
                            <input type="date" class="input-ios" style="margin:0; padding:8px 12px; width:auto;">
                            <span style="font-size:12px; font-weight:700;">s/d</span>
                            <input type="date" class="input-ios" style="margin:0; padding:8px 12px; width:auto;">
                            <button class="btn-ios" style="padding: 9px 16px; font-size:12px;" onclick="triggerAction('General', 'Filter', 'Filter Diterapkan', 'Laporan disaring berdasarkan tanggal yang dipilih.')">Filter</button>
                        </div>
                        <div style="margin-left: auto; display: flex; gap: 8px;">
                            <button class="btn-ios btn-success" style="padding: 9px 14px; font-size:12px;" onclick="exportExcel()">📥 Unduh Excel</button>
                            <button class="btn-ios btn-danger" style="padding: 9px 14px; font-size:12px;" onclick="exportPDF()">📄 Unduh PDF</button>
                        </div>
                    </div>
                    <div class="grid-hw" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
                        <div class="glass-panel hw-card"><span class="hw-title">Total Pendapatan</span><span class="hw-val" style="color: var(--success);" id="rep-income">Rp 850.000</span></div>
                        <div class="glass-panel hw-card"><span class="hw-title">Total Traffic Terpakai</span><span class="hw-val" style="color: var(--accent);" id="rep-traffic">62.2 GB</span></div>
                        <div class="glass-panel hw-card"><span class="hw-title">Pelanggan Aktif</span><span class="hw-val" id="rep-new">5 Client</span></div>
                        <div class="glass-panel hw-card"><span class="hw-title">Pelanggan Terisolir</span><span class="hw-val" style="color: var(--danger);" id="rep-isolir">1 Client</span></div>
                    </div>
                    <div class="glass-panel chart-box" style="margin-bottom: 20px;">
                        <div class="toolbar"><span class="hw-title">Grafik Pertumbuhan Pendapatan</span></div>
                        <div class="chart-canvas-wrap" style="height: 240px;"><canvas id="chartReport"></canvas></div>
                    </div>

                    <h3 style="margin-top: 24px; margin-bottom: 12px; font-size: 15px; font-weight: 700;">Rincian Transaksi Pembayaran</h3>
                    <div class="glass-panel table-container">
                        <table id="tbl-report-detail">
                            <thead><tr><th>Tanggal</th><th>Kategori</th><th>Keterangan</th><th>Nominal</th><th>Status</th></tr></thead>
                            <tbody id="tbody-report-detail">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 10: CLIENT REQUESTS / TICKETS -->
                <section id="view-ticket-kendala" class="view-section">
                    <h1 class="header-title">Tiket Kendala Pelanggan</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <input type="text" class="input-ios" placeholder="Cari tiket..." style="width: 280px; margin:0;">
                            <button class="btn-ios" onclick="openFormModal('create_ticket')">+ Buat Tiket Baru</button>
                        </div>
                        <table>
                            <thead><tr><th>No. Tiket</th><th>Pelanggan</th><th>Kendala / Keterangan</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-tickets">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <section id="view-ticket-pppoe" class="view-section">
                    <h1 class="header-title">Request Pasang Baru PPPoE</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar"><input type="text" class="input-ios" placeholder="Cari request..." style="width: 280px; margin:0;"></div>
                        <table>
                            <thead><tr><th>No. Tiket</th><th>Nama / Alamat</th><th>Paket Diajukan</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-ticket-pppoe">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 11: SPEEDTEST (BANDWIDTH TEST) -->
                <section id="view-speedtest" class="view-section">
                    <h1 class="header-title">Uji Kecepatan (Bandwidth Test)</h1>
                    <div class="glass-panel" style="padding: 32px; text-align: center; display: flex; flex-direction: column; align-items: center;">
                        <p style="font-size: 13.5px; color: var(--text-sub); margin-bottom: 25px;">Uji throughput link router dan latensi jaringan MikroTik.</p>
                        
                        <div style="position: relative; width: 300px; height: 165px; margin-bottom: 25px;">
                            <canvas id="speedGauge"></canvas>
                            <div style="position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); text-align: center;">
                                <div style="font-size: 34px; font-weight: 800; font-variant-numeric: tabular-nums;" id="st-speed-val">0.00</div>
                                <div style="font-size: 12px; color: var(--text-sub); font-weight: 700; text-transform: uppercase; letter-spacing: 1px;" id="st-speed-lbl">Mbps</div>
                            </div>
                        </div>
                        
                        <div class="grid-hw" style="width: 100%; max-width: 600px; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px;">
                            <div class="fw-box"><div class="fw-box-title">Ping</div><div class="fw-box-val" id="st-ping">-- ms</div></div>
                            <div class="fw-box"><div class="fw-box-title">Jitter</div><div class="fw-box-val" id="st-jitter">-- ms</div></div>
                            <div class="fw-box" style="border-color: rgba(0, 122, 255, 0.3);"><div class="fw-box-title">Download</div><div class="fw-box-val" id="st-dl" style="color:var(--accent);">--</div></div>
                            <div class="fw-box" style="border-color: rgba(52, 199, 89, 0.3);"><div class="fw-box-title">Upload</div><div class="fw-box-val" id="st-ul" style="color:var(--success);">--</div></div>
                        </div>

                        <button class="btn-ios" id="btn-start-speedtest" style="width: 100%; max-width: 380px; font-size: 15px; padding: 15px;" onclick="startSpeedtest()">MULAI SPEEDTEST</button>
                    </div>
                </section>

                <!-- VIEW 12: PING & TRACEROUTE -->
                <section id="view-ping" class="view-section">
                    <h1 class="header-title">Diagnostic Tools (Ping & Traceroute)</h1>
                    <div class="glass-panel" style="padding: 26px;">
                        <div class="form-grid" style="grid-template-columns: 1fr 180px 140px; align-items: end; margin-bottom: 20px;">
                            <div><span class="form-label">IP / Domain Target</span><input type="text" id="ping-target" class="input-ios" placeholder="8.8.8.8 atau 192.168.10.15" value="8.8.8.8"></div>
                            <div><span class="form-label">Tipe Tool</span><select id="ping-tool" class="input-ios"><option value="ping">Ping (ICMP)</option><option value="trace">Traceroute</option></select></div>
                            <button class="btn-ios" id="btn-exec-ping" style="margin-bottom: 12px;" onclick="executePingTrace()">Jalankan Tool</button>
                        </div>
                        
                        <div style="position: relative;">
                            <div class="code-preview" id="ping-terminal" style="min-height: 280px; max-height: 400px; text-align: left; overflow-y: auto;">
[admin@Core-CCR1036] > Terminal Diagnostic Siap.<br>
RouterOS v7.14 REST API terhubung. Silakan jalankan Ping atau Traceroute...
                            </div>
                            <div id="ping-loader" class="di-loader" style="position: absolute; top: 18px; right: 22px; display: none; border-top-color: var(--success); width: 20px; height: 20px;"></div>
                        </div>
                    </div>
                </section>

                <!-- VIEW 13: SYSTEM CONFIGURATIONS -->
                <section id="view-system-mikrotik" class="view-section">
                    <h1 class="header-title">MikroTik REST API Configuration</h1>
                    <div class="grid-hw" style="grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="glass-panel" style="padding: 26px;">
                            <h3 style="margin-bottom: 18px;">Kredensial RouterOS v7</h3>
                            <div class="form-grid" style="margin: 0;">
                                <span class="form-label">Host / IP Address</span><input type="text" id="set-mik-host" class="input-ios" placeholder="https://192.168.88.1">
                                <span class="form-label">REST API Port</span><input type="text" id="set-mik-port" class="input-ios" placeholder="443">
                                <span class="form-label">Username</span><input type="text" id="set-mik-user" class="input-ios" placeholder="admin">
                                <span class="form-label">Password</span><input type="password" id="set-mik-pass" class="input-ios" placeholder="******">
                                <span class="form-label">RADIUS Secret</span><input type="password" id="set-radius-sec" class="input-ios" placeholder="radsec123">
                            </div>
                            <button class="btn-ios" style="width: 100%; margin-top: 16px;" onclick="saveSettings('mikrotik')">Simpan Konfigurasi</button>
                        </div>
                        <div class="glass-panel" style="padding: 26px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                            <div style="font-size: 44px; margin-bottom: 12px;">☁️</div>
                            <h3 style="margin-bottom: 8px;">Status Koneksi API</h3>
                            <span class="badge badge-active" style="font-size: 13px; padding: 7px 16px;">Active & Ready</span>
                            <p style="font-size: 12.5px; color: var(--text-sub); margin-top: 14px;">Router: Core-CCR1036 | Version: 7.14</p>
                            <button class="btn-ios btn-outline" style="margin-top: 18px;" onclick="triggerAction('General', 'Test Koneksi API RouterOS', 'Koneksi Stabil', 'Ping ke Router 2ms. REST API merespon dengan baik.')">Uji Koneksi</button>
                        </div>
                    </div>
                </section>

                <section id="view-system-telegram" class="view-section">
                    <h1 class="header-title">Telegram Bot Integration</h1>
                    <div class="glass-panel" style="padding: 26px; max-width: 600px;">
                        <h3 style="margin-bottom: 18px;">Pengaturan Bot & Webhook</h3>
                        <div class="form-grid" style="margin: 0;">
                            <span class="form-label">Bot Token</span><input type="password" id="set-tg-token" class="input-ios" placeholder="123456789:ABCDEF...">
                            <span class="form-label">Owner / Group Chat ID</span><input type="text" id="set-tg-chat" class="input-ios" placeholder="-100123456789">
                        </div>
                        <button class="btn-ios" style="width: 100%; margin-top: 16px;" onclick="saveSettings('telegram')">Simpan Konfigurasi Telegram</button>
                    </div>
                </section>

                <section id="view-system-wa" class="view-section">
                    <h1 class="header-title">WhatsApp Gateway Integration</h1>
                    <div class="grid-hw" style="grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="glass-panel" style="padding: 26px;">
                            <h3 style="margin-bottom: 18px;">Gateway Server</h3>
                            <div class="form-grid" style="margin: 0;">
                                <span class="form-label">Server URL</span><input type="text" id="set-wa-url" class="input-ios" placeholder="http://localhost:3000">
                                <span class="form-label">API Token</span><input type="password" id="set-wa-token" class="input-ios" placeholder="token123">
                            </div>
                            <button class="btn-ios btn-outline" style="width: 100%; margin-top: 16px;" onclick="saveSettings('wa')">Simpan Konfigurasi WA</button>
                        </div>
                        <div class="glass-panel" style="padding: 26px;">
                            <h3 style="margin-bottom: 18px;">Uji Broadcast Pesan</h3>
                            <div class="form-grid" style="margin: 0;">
                                <span class="form-label">Nomor Tujuan</span><input type="text" class="input-ios" placeholder="628123456789">
                                <span class="form-label">Isi Pesan</span><textarea class="input-ios" placeholder="Ketik pesan percobaan..."></textarea>
                            </div>
                            <button class="btn-ios btn-success" style="width: 100%; margin-top: 16px;" onclick="triggerAction('General', 'Pesan Test WA', 'Terkirim', 'Pesan percobaan WhatsApp berhasil diteruskan ke gateway.')">Kirim Pesan Uji</button>
                        </div>
                    </div>
                </section>

                <section id="view-system-audit" class="view-section">
                    <h1 class="header-title">System Logs & Audit Trail</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar"><input type="text" class="input-ios" placeholder="Cari log audit..." style="width: 280px; margin:0;"></div>
                        <table id="tbl-audit-log">
                            <thead><tr><th>Waktu (WIB)</th><th>User / Role</th><th>Aktivitas</th><th>Target</th><th>Otorisasi</th></tr></thead>
                            <tbody id="tbody-audit-log">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 14: OWNER APPROVAL CENTER -->
                <section id="view-approval-center" class="view-section">
                    <h1 class="header-title" style="color: var(--warning);">👑 Owner Approval Center</h1>
                    <div class="grid-hw">
                        <div class="glass-panel hw-card"><span class="hw-title">Pending Request</span><span class="hw-val" style="color: var(--warning);" id="appr-pending">2</span></div>
                        <div class="glass-panel hw-card"><span class="hw-title">Disetujui Hari Ini</span><span class="hw-val" style="color: var(--success);">14</span></div>
                        <div class="glass-panel hw-card"><span class="hw-title">Critical Command</span><span class="hw-val" style="color: var(--danger);">1</span></div>
                        <div class="glass-panel hw-card"><span class="hw-title">Rata-Rata Waktu Respon</span><span class="hw-val">1.8 min</span></div>
                    </div>
                    <div class="glass-panel table-container">
                        <table id="tbl-approval">
                            <thead><tr><th>Status</th><th>Risk Level</th><th>Tanggal & Waktu</th><th>Admin</th><th>Command</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-approval">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 15: ADMIN DAILY REPORTS -->
                <section id="view-admin-report" class="view-section">
                    <h1 class="header-title">Laporan Shift & Aktivitas Admin</h1>
                    <div class="glass-panel table-container">
                        <table id="tbl-admin-reports">
                            <thead><tr><th>Tanggal & Jam</th><th>Admin</th><th>Status Shift</th><th>Kendala / Gangguan</th><th>Perbaikan Dilakukan</th></tr></thead>
                            <tbody id="tbody-admin-reports">
                                <tr><td>15 Sep 2026, 08:00</td><td>Toni Kurniawan</td><td><span class="badge badge-active">Normal</span></td><td>Nihil</td><td>Pemeriksaan Morning Checklist & backup RADIUS</td></tr>
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- VIEW 16: ROLE & CREDENTIAL MANAGEMENT -->
                <section id="view-role-manage" class="view-section">
                    <h1 class="header-title">Manajemen Kredensial Administrator</h1>
                    <div class="glass-panel table-container">
                        <div class="toolbar">
                            <button class="btn-ios" onclick="openRoleDetailModal('', '', 'admin', 'Active')">+ Tambah Admin Baru</button>
                        </div>
                        <table id="tbl-role-manage">
                            <thead><tr><th>Nama Lengkap</th><th>Username</th><th>Role</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody id="tbody-role-manage">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </section>

            </main>
        </div>
    </div>

    <!-- ============================================== -->
    <!-- FLOATING LIVE WIDGET (ADMIN)                   -->
    <!-- ============================================== -->
    <div id="floating-widget" class="collapsed">
        <div class="fw-header" id="fw-handle">
            <div class="fw-title"><div class="fw-live-dot"></div> Live MikroTik & RADIUS</div>
            <button class="fw-btn-collapse" onclick="toggleFloatingWidget(event)">—</button>
        </div>
        <div class="fw-icon-collapsed" onclick="toggleFloatingWidget(event)">
            ⚡<div class="fw-notif-badge"></div>
        </div>
        <div class="fw-content">
            <div class="fw-grid-2">
                <div class="fw-box"><div class="fw-box-title">CPU Load</div><div class="fw-box-val" id="fw-cpu-val" style="color: var(--success);">18%</div></div>
                <div class="fw-box"><div class="fw-box-title">Total Traffic</div><div class="fw-box-val" style="color: var(--accent);">230M</div><div class="fw-box-sub" id="fw-rx-tx-val">DL: 150M | UL: 80M</div></div>
            </div>
            <div class="fw-chart-wrap"><canvas id="fwMiniChart"></canvas></div>
            <div style="background: rgba(255,255,255,0.7); padding: 10px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.05);">
                <div class="fw-status-item"><span style="font-weight:600;"><span class="fw-dot green"></span>ISP Utama</span><span>Normal (Ping 2ms)</span></div>
                <div class="fw-status-item"><span style="font-weight:600;"><span class="fw-dot green"></span>RADIUS Auth</span><span>Online</span></div>
                <div class="fw-status-item"><span style="font-weight:600;"><span class="fw-dot green"></span>Supabase DB</span><span>Connected</span></div>
            </div>
            <div class="fw-action-grid">
                <button class="btn-ios" style="padding: 8px; font-size:11px;" onclick="triggerAction('General', 'Backup Database RADIUS', 'Backup Selesai', 'Cadangan database RADIUS berhasil dibuat.')">💾 Backup</button>
                <button class="btn-ios btn-outline" style="padding: 8px; font-size:11px;" onclick="triggerAction('General', 'Reload FreeRADIUS Service', 'Reload Selesai', 'Service RADIUS telah direfresh.')">🔄 Reload</button>
            </div>
        </div>
    </div>

    <!-- OWNER FLOATING WIDGET -->
    <div id="owner-widget" onclick="switchView('view-approval-center', document.getElementById('nav-approval-center') || document.body)">
        <div class="ow-icon">🔔</div>
        <div class="ow-text">Approval<br>Pending</div>
        <div class="ow-val" id="ow-pending-count">2</div>
    </div>

    <!-- ============================================== -->
    <!-- MODALS & POPUPS                                -->
    <!-- ============================================== -->

    <!-- VOUCHER PRINT MODAL (THERMAL TEMPLATE) -->
    <div class="overlay" id="voucher-print-modal">
        <div class="glass-panel popup-box" style="max-width: 780px;">
            <button class="close-btn" onclick="closeModal('voucher-print-modal')">✕</button>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 14px;">
                <h2 style="font-weight: 800;">🖨️ Pratinjau Cetak Voucher Hotspot</h2>
                <button class="btn-ios" onclick="window.print()">🖨️ Cetak Sekarang</button>
            </div>
            <p style="font-size: 13px; color: var(--text-sub); margin-bottom: 20px;">Format stempel kartu siap cetak ke printer thermal 58mm / 80mm atau kertas A4.</p>
            
            <div id="print-area">
                <div class="voucher-grid-print" id="voucher-print-cards">
                    <!-- Cards will be populated dynamically -->
                </div>
            </div>
        </div>
    </div>

    <!-- DAILY REPORT MODAL BEFORE LOGOUT -->
    <div class="overlay" id="daily-report-modal" style="z-index: 7000;">
        <div class="glass-panel popup-box" style="max-width: 480px;">
            <button class="close-btn" onclick="closeModal('daily-report-modal')">✕</button>
            <h2 style="margin-bottom: 4px; font-weight: 800;">Laporan Shift Harian</h2>
            <p style="font-size: 13px; color: var(--text-sub); margin-bottom: 18px;">Wajib mengisi rangkuman sebelum logout demi kelancaran operasional.</p>
            
            <div class="form-grid">
                <span class="form-label">Kondisi Jaringan Hari Ini *</span>
                <select class="input-ios" id="rep-status">
                    <option value="Normal">Normal & Stabil</option>
                    <option value="Maintenance">Sedang Pemeliharaan</option>
                    <option value="Gangguan">Terdapat Gangguan</option>
                </select>
                <span class="form-label">Kendala / Insiden Hari Ini *</span>
                <textarea class="input-ios" id="rep-gangguan" placeholder="Tuliskan kendala jaringan jika ada... (atau 'Nihil')">Nihil</textarea>
                <span class="form-label">Perbaikan & Aktivitas Selesai *</span>
                <textarea class="input-ios" id="rep-perbaikan" placeholder="Aktivitas perbaikan atau instalasi baru..."></textarea>
            </div>
            <div id="rep-err-msg" style="color: var(--danger); font-size: 12px; font-weight: 700; display: none; margin-bottom: 8px;">Semua field bertanda (*) wajib diisi.</div>
            <button class="btn-ios" style="width: 100%; padding: 14px;" onclick="submitDailyReport()">Simpan Laporan & Logout</button>
        </div>
    </div>

    <!-- CLIENT DETAIL & EDIT MODAL -->
    <div class="overlay" id="universal-modal">
        <div class="glass-panel popup-box">
            <button class="close-btn" onclick="closeModal('universal-modal')">✕</button>
            <h2 id="modal-title" style="margin-bottom: 4px; font-weight: 800;">Detail Client</h2>
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div style="font-size: 12px; color: var(--accent); font-weight: 700; text-transform: uppercase;" id="modal-subtitle">RADIUS Account</div>
                <span id="det-status-badge" class="badge">Status</span>
            </div>
            <div id="block-detail" style="margin-top: 18px;">
                <div style="background: rgba(255,255,255,0.7); padding: 15px; border-radius: 14px; margin-bottom: 16px; text-align: center; border: 1px solid rgba(0,0,0,0.05);">
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-sub); text-transform: uppercase;">Total Penggunaan Trafik Sesi</div>
                    <div style="font-size: 1.5rem; font-weight: 800; color: var(--accent); margin: 4px 0;" id="det-total-usage">0 GB</div>
                    <div style="height: 100px; width: 100%; position: relative;"><canvas id="miniClientChart"></canvas></div>
                </div>
                <div class="form-grid two-cols">
                    <div><span class="form-label">Username RADIUS</span><input type="text" class="input-ios" id="det-edit-user"></div>
                    <div><span class="form-label">Password RADIUS</span><input type="text" class="input-ios" id="det-edit-pass"></div>
                    <div><span class="form-label">IP Address</span><input type="text" class="input-ios" id="det-edit-ip"></div>
                    <div><span class="form-label">MAC Address</span><input type="text" class="input-ios" id="det-edit-mac"></div>
                    <div><span class="form-label">Paket Layanan</span><select class="input-ios" id="det-edit-paket"><option>VIP_400M</option><option>REG_50M</option><option>REG_20M</option><option>Voucher 5 Jam</option><option>Hotspot VIP</option></select></div>
                    <div><span class="form-label">Perangkat Client</span><input type="text" class="input-ios" id="det-edit-device"></div>
                </div>
                <div class="action-btn-grid" id="action-buttons-container"></div>
            </div>
        </div>
    </div>

    <!-- DYNAMIC FORM MODAL -->
    <div class="overlay" id="form-modal">
        <div class="glass-panel popup-box" style="max-width: 440px;">
            <button class="close-btn" onclick="closeModal('form-modal')">✕</button>
            <h2 id="form-title" style="font-weight: 800; margin-bottom: 12px;">Tambah Data</h2>
            <div id="dynamic-form-fields" class="form-grid"></div>
            <button class="btn-ios" style="width: 100%; margin-top: 14px;" onclick="submitFormModal()">Simpan ke Supabase</button>
        </div>
    </div>

    <!-- SECURITY PIN MODAL FOR SENSITIVE ACTIONS -->
    <div class="overlay" id="pin-modal" style="z-index: 5010;">
        <div class="glass-panel popup-box" style="text-align: center; max-width: 360px;">
            <button class="close-btn" onclick="closeModal('pin-modal')">✕</button>
            <h2 style="margin-bottom: 4px; font-weight: 800;">Otorisasi PIN</h2>
            <p style="font-size: 13px; color: var(--text-sub); font-weight: 500;">Tindakan ini memerlukan verifikasi PIN.</p>
            <p style="font-size: 11px; color: var(--accent); margin-top: 4px; font-weight: 600;">(PIN Default = 1234)</p>
            <div class="pin-input-group">
                <input type="password" class="pin-box" id="pin1" readonly tabindex="-1"><input type="password" class="pin-box" id="pin2" readonly tabindex="-1">
                <input type="password" class="pin-box" id="pin3" readonly tabindex="-1"><input type="password" class="pin-box" id="pin4" readonly tabindex="-1">
            </div>
            <div class="custom-keypad">
                <button class="key-btn" onclick="pressActionPin(1)">1</button><button class="key-btn" onclick="pressActionPin(2)">2</button><button class="key-btn" onclick="pressActionPin(3)">3</button>
                <button class="key-btn" onclick="pressActionPin(4)">4</button><button class="key-btn" onclick="pressActionPin(5)">5</button><button class="key-btn" onclick="pressActionPin(6)">6</button>
                <button class="key-btn" onclick="pressActionPin(7)">7</button><button class="key-btn" onclick="pressActionPin(8)">8</button><button class="key-btn" onclick="pressActionPin(9)">9</button>
                <button class="key-btn key-action" onclick="clearActionPin()">C</button><button class="key-btn" onclick="pressActionPin(0)">0</button><button class="key-btn key-action" onclick="deleteActionPin()">⌫</button>
            </div>
        </div>
    </div>

    <!-- PROCESS ANIMATION MODAL -->
    <div class="overlay" id="process-modal" style="z-index: 10005;">
        <div class="glass-panel popup-box" style="text-align: center; max-width: 320px; padding: 36px 28px;">
            <div class="status-view" style="padding: 0;">
                <div class="morph-wrapper" id="anim-morph">
                    <svg class="morph-svg" viewBox="0 0 60 60"><circle class="track-circle" cx="30" cy="30" r="26"></circle><circle class="draw-circle" cx="30" cy="30" r="26"></circle><polyline class="check-line" points="18 31 26 39 42 22"></polyline><path class="cross-line" d="M20 20 L40 40 M40 20 L20 40"></path></svg>
                </div>
                <h3 id="anim-title" style="margin-top: 10px; font-size: 1.35rem; font-weight: 800;">Memproses...</h3>
                <p id="anim-sub" style="font-size: 13px; color: var(--text-sub); margin-top: 5px; font-weight: 500;">Menghubungi Server</p>
            </div>
        </div>
    </div>

    <!-- ADMIN WAITING OWNER APPROVAL MODAL -->
    <div class="overlay" id="admin-waiting-modal" style="z-index: 5500;">
        <div class="glass-panel popup-box" style="text-align: center; max-width: 380px;">
            <button class="close-btn" onclick="closeModal('admin-waiting-modal')">✕</button>
            <div class="di-loader" style="width:42px; height:42px; border-width:4px; border-color: rgba(0,0,0,0.1); border-top-color: var(--warning); margin: 0 auto 16px;"></div>
            <h2 style="margin-bottom: 4px; color: var(--warning); font-weight: 800;">Menunggu Otorisasi Owner</h2>
            <p style="font-size: 13px; color: var(--text-sub); font-weight: 500; margin-bottom: 20px;">Instruksi tingkat risiko tinggi memerlukan izin Owner.</p>
            <div style="background: rgba(255,255,255,0.7); padding: 15px; border-radius: 14px; text-align: left; margin-bottom: 20px; border: 1px solid rgba(0,0,0,0.05);">
                <div style="font-size: 12px; margin-bottom: 8px;"><span style="color:var(--text-sub); font-weight:600; display:block; text-transform:uppercase; font-size:10px;">Perintah</span><span style="font-weight:700;" id="wait-cmd">Delete Client</span></div>
                <div style="font-size: 12px;"><span style="color:var(--text-sub); font-weight:600; display:block; text-transform:uppercase; font-size:10px;">Tingkat Risiko</span><span class="badge badge-danger">Critical</span></div>
            </div>
            <p style="font-size: 11.5px; color: var(--text-sub); font-style: italic;">Pemberitahuan telah diteruskan ke Telegram Owner.</p>
        </div>
    </div>

    <!-- OWNER APPROVAL MINI CONSOLE -->
    <div class="overlay" id="owner-approval-modal" style="z-index: 5500;">
        <div class="glass-panel popup-box" style="max-width: 580px;">
            <button class="close-btn" onclick="closeModal('owner-approval-modal')">✕</button>
            <h2 style="margin-bottom: 4px; font-weight: 800;">Mini Console Approval</h2>
            <p style="font-size: 12.5px; color: var(--text-sub); margin-bottom: 20px;">Tinjau permintaan instruksi dari administrator.</p>
            <div class="form-grid two-cols" style="background: rgba(255,255,255,0.7); padding: 16px; border-radius: 14px; margin-bottom: 16px; border: 1px solid rgba(0,0,0,0.05);">
                <div><span class="form-label">Request ID</span><span style="font-weight:800;" id="det-req-id">REQ-1001</span></div>
                <div><span class="form-label">Admin Pemohon</span><span style="font-weight:700;" id="det-req-admin">Toni</span></div>
                <div><span class="form-label">Router Target</span><span style="font-weight:700;" id="det-req-router">Core-CCR1036</span></div>
                <div><span class="form-label">Risk Level</span><span class="badge badge-danger" id="det-req-risk">Critical</span></div>
            </div>
            <div style="margin-bottom: 6px;"><span class="form-label" style="margin-left:0;">Cuplikan Perintah</span></div>
            <div class="code-preview" id="det-req-cmd">--</div>
            <div class="action-btn-grid" style="grid-template-columns: repeat(3, 1fr);">
                <button class="btn-ios btn-success" onclick="processOwnerApproval('Approve')">Setujui (Approve)</button>
                <button class="btn-ios btn-danger" onclick="processOwnerApproval('Reject')">Tolak (Reject)</button>
                <button class="btn-ios btn-outline" onclick="processOwnerApproval('Hold')">Tunda (Hold)</button>
            </div>
        </div>
    </div>

    <!-- ROLE EDIT MODAL -->
    <div class="overlay" id="role-detail-modal">
        <div class="glass-panel popup-box" style="max-width: 500px;">
            <button class="close-btn" onclick="closeModal('role-detail-modal')">✕</button>
            <h2 style="margin-bottom: 4px; font-weight: 800;">Profil Akun Administrator</h2>
            <p style="font-size: 12.5px; color: var(--text-sub); margin-bottom: 18px;">Pengaturan kredensial login dan PIN otorisasi.</p>
            <div class="form-grid two-cols">
                <div><span class="form-label">Nama Lengkap</span><input type="text" class="input-ios" id="role-edit-name"></div>
                <div><span class="form-label">Hak Akses (Role)</span><select class="input-ios" id="role-edit-role"><option value="admin">Admin</option><option value="owner">Owner</option></select></div>
                <div><span class="form-label">Username</span><input type="text" class="input-ios" id="role-edit-user"></div>
                <div><span class="form-label">Password Baru</span><input type="password" class="input-ios" id="role-edit-pass"></div>
                <div><span class="form-label">PIN Otorisasi (4 Digit)</span><input type="password" class="input-ios" id="role-edit-pin" maxlength="4"></div>
            </div>
            <button class="btn-ios" style="width: 100%; margin-top: 14px;" onclick="saveAdminUser()">Simpan Akun</button>
        </div>
    </div>

    <!-- JAVASCRIPT LOGIC -->
    <script>
        let userRole = 'admin';
        let activeUser = 'Admin';
        let pendingActionContext = null;
        let pendingActionPayload = null;
        let pendingSuccessTitle = 'Tereksekusi!';
        let pendingSuccessMsg = 'Instruksi berhasil dijalankan.';
        let currentRequestId = null;
        let isSystemFrozen = false;
        let isEditModeGlobal = false;
        let activeFormType = '';

        let fwMiniChartInstance, shaperChartInstance, reportChartInstance;
        let miniClientChartInstance, speedGaugeInstance;
        let livePollingInterval, processTimeout1, processTimeout2;

        const checklistTasks = [
            "MikroTik REST API (v7)", "FreeRADIUS Server AAA", "Supabase PostgreSQL Database", 
            "PPPoE Daemon Service", "Hotspot Daemon Service", "WhatsApp Gateway Service", 
            "Telegram Bot Webhook", "Cloudflare Worker Edge", "Sistem Isolir Otomatis", 
            "Alokasi Bandwidth Matrix", "Sinkronisasi Waktu NTP", "CPU Load Router", 
            "Free Memory RAM", "Disk Storage NVRAM", "Pemeriksaan Audit Trail"
        ];

        async function startChecklistFlow() {
            let userInput = document.getElementById('login-user').value.trim();
            let passInput = document.getElementById('login-pass').value.trim();
            
            showProcessAnim('Memverifikasi...', 'Menghubungi Supabase');
            
            try {
                const res = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username: userInput, password: passInput })
                });
                const data = await res.json();
                
                if (data.success) {
                    activeUser = data.user || userInput;
                    userRole = data.role || 'admin';
                    localStorage.setItem('auth_token', data.token || 'token');
                    document.getElementById('display-user').innerText = activeUser;
                    
                    setTimeout(() => {
                        finishProcessAnim('Login Berhasil', 'Memulai Checklist...', 'success', true);
                        setTimeout(() => {
                            document.getElementById('login-screen').style.opacity = '0';
                            setTimeout(() => {
                                document.getElementById('login-screen').style.display = 'none';
                                document.getElementById('checklist-screen').style.display = 'flex';
                                runChecklistSequence();
                            }, 400);
                        }, 1200);
                    }, 800);
                } else {
                    finishProcessAnim('Login Gagal', data.message || 'Kredensial tidak valid', 'error', true);
                    setTimeout(() => closeModal('process-modal'), 2000);
                }
            } catch (err) {
                finishProcessAnim('Error Server', 'Tidak dapat menghubungi Worker', 'error', true);
                setTimeout(() => closeModal('process-modal'), 2000);
            }
        }

        async function runChecklistSequence() {
            const container = document.getElementById('chk-container'), progBar = document.getElementById('chk-bar'), progPct = document.getElementById('chk-prog-pct'), finalMsg = document.getElementById('chk-final-msg');
            container.innerHTML = '';
            
            for(let i=0; i<checklistTasks.length; i++) {
                let li = document.createElement('li'); li.className = 'chk-item'; li.innerHTML = '<div class="chk-icon chk-spin"></div> <span>' + checklistTasks[i] + '...</span>';
                container.appendChild(li); container.scrollTop = container.scrollHeight;
                setTimeout(() => li.classList.add('show'), 50);
                await new Promise(r => setTimeout(r, 120));
                
                li.querySelector('.chk-icon').className = 'chk-icon chk-ok';
                li.querySelector('.chk-icon').innerHTML = '✓';
                li.querySelector('span').innerText = checklistTasks[i] + ' — OK';
                
                let p = Math.round(((i + 1) / checklistTasks.length) * 100);
                progBar.style.width = p + '%'; progPct.innerText = p + '%';
            }
            
            document.getElementById('chk-prog-text').innerText = "Selesai";
            progBar.style.background = "var(--success)";
            finalMsg.innerHTML = '<span style="color:var(--success);">Semua Layanan Siap</span><br><span style="font-size:12px; color:var(--text-sub); font-weight:500;">RADIUS & MikroTik terhubung sempurna.</span>';
            finalMsg.style.opacity = '1';
            
            setTimeout(() => {
                document.getElementById('checklist-screen').style.opacity = '0';
                setTimeout(() => {
                    document.getElementById('checklist-screen').style.display = 'none';
                    document.getElementById('login-pin-screen').style.display = 'flex';
                    document.getElementById('lpin1').classList.add('active');
                }, 400);
            }, 1800);
        }

        /* --- LOGIN PIN --- */
        let loginPinIdx = 1;
        function pressLoginPin(num) {
            if (loginPinIdx <= 4) {
                let box = document.getElementById('lpin' + loginPinIdx);
                box.value = num; box.classList.remove('active'); loginPinIdx++;
                if (loginPinIdx <= 4) { document.getElementById('lpin' + loginPinIdx).classList.add('active'); }
                else { setTimeout(verifyLoginPin, 150); }
            }
        }
        function deleteLoginPin() {
            if (loginPinIdx > 1) {
                if (loginPinIdx <= 4) document.getElementById('lpin' + loginPinIdx).classList.remove('active');
                loginPinIdx--; let box = document.getElementById('lpin' + loginPinIdx);
                box.value = ''; box.classList.add('active');
            }
        }
        function clearLoginPin() {
            for (let i = 1; i <= 4; i++) { let box = document.getElementById('lpin' + i); box.value = ''; box.classList.remove('active'); }
            loginPinIdx = 1; document.getElementById('lpin1').classList.add('active');
        }

        async function verifyLoginPin() {
            let entered = document.getElementById('lpin1').value + document.getElementById('lpin2').value + document.getElementById('lpin3').value + document.getElementById('lpin4').value;
            let pinBox = document.getElementById('login-pin-box'), errText = document.getElementById('login-pin-error'), group = document.getElementById('login-pin-group');
            
            try {
                const res = await fetch('/api/auth/verify-pin', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ pin: entered, username: document.getElementById('login-user').value.trim() })
                });
                const data = await res.json();
                
                if (data.success) {
                    errText.style.opacity = '0';
                    showProcessAnim('Otorisasi...', '');
                    setTimeout(() => {
                        finishProcessAnim('Terverifikasi', 'Akses Diberikan', 'success', false);
                        setTimeout(prepareSmartGreeting, 1000);
                    }, 600);
                } else {
                    errText.style.opacity = '1';
                    group.querySelectorAll('.pin-box').forEach(b => b.classList.add('err'));
                    pinBox.classList.add('shake-err');
                    setTimeout(() => {
                        pinBox.classList.remove('shake-err');
                        group.querySelectorAll('.pin-box').forEach(b => b.classList.remove('err'));
                        clearLoginPin();
                    }, 450);
                }
            } catch(e) {
                if (entered === '1234') {
                    errText.style.opacity = '0';
                    showProcessAnim('Otorisasi...', '');
                    setTimeout(() => {
                        finishProcessAnim('Terverifikasi', 'Akses Diberikan', 'success', false);
                        setTimeout(prepareSmartGreeting, 1000);
                    }, 600);
                }
            }
        }

        /* --- SMART GREETING & SPLASH SCREEN --- */
        const quotes = [
            "Semoga jaringan hari ini berjalan lancar.",
            "Selamat bekerja, jangan lupa memeriksa sesi RADIUS.",
            "Pantau selalu traffic agar pelanggan tetap nyaman.",
            "Sistem stabil adalah kunci kepuasan pelanggan."
        ];

        function prepareSmartGreeting() {
            closeModal('process-modal');
            document.getElementById('login-pin-screen').style.opacity = '0';
            
            setTimeout(async () => {
                document.getElementById('login-pin-screen').style.display = 'none';
                const hour = new Date().getHours();
                let timeStr = "Pagi";
                if(hour >= 11 && hour < 15) timeStr = "Siang";
                else if(hour >= 15 && hour < 19) timeStr = "Sore";
                else if(hour >= 19 || hour < 4) timeStr = "Malam";
                
                document.getElementById('greet-header').innerText = 'Selamat ' + timeStr + ', ' + activeUser + ' 👋';
                document.getElementById('greet-quote').innerText = '"' + quotes[Math.floor(Math.random() * quotes.length)] + '"';
                
                document.getElementById('display-role').innerText = userRole.toUpperCase();
                if(userRole === 'owner') {
                    document.getElementById('display-role').style.background = 'rgba(255, 149, 0, 0.15)';
                    document.getElementById('display-role').style.color = 'var(--warning)';
                    document.getElementById('menu-owner-group').style.display = 'block';
                    document.getElementById('menu-system-audit').style.display = 'flex';
                    document.getElementById('owner-widget').style.display = 'flex';
                } else {
                    document.getElementById('menu-owner-group').style.display = 'none';
                    document.getElementById('menu-system-audit').style.display = 'none';
                    document.getElementById('owner-widget').style.display = 'none';
                }
                document.getElementById('greeting-screen').style.display = 'flex';

                let countdown = 3;
                const countdownEl = document.getElementById('greet-countdown');
                const countdownTimer = setInterval(() => {
                    countdown--;
                    if (countdown > 0) {
                        countdownEl.innerText = 'Memasuki dasbor dalam ' + countdown + ' detik...';
                    } else {
                        clearInterval(countdownTimer);
                        countdownEl.innerText = 'Memuat dasbor...';
                        enterDashboard();
                    }
                }, 1000);
            }, 400);
        }

        function enterDashboard() {
            document.getElementById('greet-box').style.animation = 'fadeScaleOut 0.4s forwards';
            setTimeout(() => {
                document.getElementById('greeting-screen').style.display = 'none';
                
                const splash = document.getElementById('splash-screen');
                const logo = document.getElementById('splash-logo');
                const sub = document.getElementById('splash-sub');
                
                splash.style.opacity = '1';
                splash.style.display = 'flex';
                logo.innerText = '';
                sub.style.opacity = '0';
                
                const text = "_uvwxyz";
                let i = 0;
                function typeWriter() {
                    if (i < text.length) {
                        logo.innerHTML += text.charAt(i);
                        i++;
                        setTimeout(typeWriter, 140);
                    } else {
                        setTimeout(() => {
                            sub.style.opacity = '1';
                            setTimeout(() => {
                                splash.style.opacity = '0';
                                setTimeout(() => {
                                    splash.style.display = 'none';
                                    document.getElementById('app-layout').style.display = 'flex';
                                    setTimeout(() => {
                                        document.getElementById('app-layout').style.opacity = '1';
                                        initAllSystem();
                                    }, 50);
                                }, 400);
                            }, 900);
                        }, 400);
                    }
                }
                setTimeout(typeWriter, 300);
            }, 400);
        }

        /* --- INITIALIZATION OF CHARTS & DATA --- */
        function initAllSystem() {
            initTrafficCharts();
            initReportChart();
            initShaperChart();
            initFloatingWidgetChart();
            initSpeedGauge();
            
            fetchMikrotikStatus();
            fetchMikrotikClients();
            fetchRadiusSessions();
            fetchVouchers();
            fetchTickets();
            fetchApprovals();
            fetchAuditLogs();
            fetchAdminUsers();
            loadSettings();
            
            // Start real-time live telemetry polling every 3.5 seconds
            livePollingInterval = setInterval(() => {
                fetchMikrotikStatus();
                fetchRadiusSessions();
            }, 3500);
        }

        function initTrafficCharts() {
            const makeChart = (id) => new Chart(document.getElementById(id).getContext('2d'), {
                type: 'line',
                data: {
                    labels: ['','','','','',''],
                    datasets: [
                        { label: 'Download', data: [15, 25, 20, 35, 30, 42], borderColor: '#007aff', backgroundColor: 'rgba(0,122,255,0.08)', fill: true, tension: 0.4, borderWidth: 2, pointRadius: 0 },
                        { label: 'Upload', data: [5, 10, 8, 15, 12, 18], borderColor: '#34c759', backgroundColor: 'rgba(52,199,89,0.08)', fill: true, tension: 0.4, borderWidth: 2, pointRadius: 0 }
                    ]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { x: { display: false }, y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } } }
                }
            });
            window.chartWanInstance = makeChart('chartWan');
            window.chartPppoeInstance = makeChart('chartPppoe');
            window.chartHotspotInstance = makeChart('chartHotspot');
            window.chartAdminInstance = makeChart('chartAdmin');
        }

        function initReportChart() {
            const ctx = document.getElementById('chartReport').getContext('2d');
            reportChartInstance = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep'],
                    datasets: [{
                        label: 'Pendapatan (Rp)',
                        data: [450000, 650000, 700000, 800000, 820000, 850000],
                        backgroundColor: 'rgba(0, 122, 255, 0.85)',
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } }, x: { grid: { display: false } } }
                }
            });
        }

        function initShaperChart() {
            const ctx = document.getElementById('shaperDonut').getContext('2d');
            shaperChartInstance = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['PPPoE VIP', 'PPPoE Regular', 'Hotspot Shared', 'Headroom'],
                    datasets: [{
                        data: [400, 350, 150, 100],
                        backgroundColor: ['#007aff', '#34c759', '#ff9500', 'rgba(0,0,0,0.06)'],
                        borderWidth: 0, hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false, cutout: '76%',
                    plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 10.5 } } } }
                }
            });
        }

        function updateShaperMatrix() {
            let maxWan = 1000;
            let valVip = parseInt(document.getElementById('slider-vip').value);
            let valReg = parseInt(document.getElementById('slider-reg').value);
            let valHot = parseInt(document.getElementById('slider-hot').value);
            
            document.getElementById('val-vip').innerText = valVip + " Mbps";
            document.getElementById('val-reg').innerText = valReg + " Mbps";
            document.getElementById('val-hot').innerText = valHot + " Mbps";
            
            let total = valVip + valReg + valHot;
            document.getElementById('shaper-total-text').innerText = total + " Mbps";
            let btnApply = document.getElementById('btn-apply-shaper');
            let idleVal = maxWan - total;
            
            if (total > maxWan) {
                document.getElementById('shaper-total-text').style.color = "var(--danger)";
                btnApply.disabled = true;
                shaperChartInstance.data.datasets[0].data = [valVip, valReg, valHot, 0];
                document.getElementById('donut-idle-text').innerText = "0M";
                document.getElementById('donut-idle-text').style.color = "var(--danger)";
            } else {
                document.getElementById('shaper-total-text').style.color = "var(--text-main)";
                btnApply.disabled = false;
                shaperChartInstance.data.datasets[0].data = [valVip, valReg, valHot, idleVal];
                document.getElementById('donut-idle-text').innerText = idleVal + "M";
                document.getElementById('donut-idle-text').style.color = "var(--text-main)";
            }
            shaperChartInstance.update();
        }

        function initFloatingWidgetChart() {
            const ctx = document.getElementById('fwMiniChart').getContext('2d');
            fwMiniChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['1', '2', '3', '4', '5', '6'],
                    datasets: [
                        { label: 'DL', data: [15, 20, 18, 25, 22, 30], borderColor: '#007aff', borderWidth: 2, tension: 0.4, pointRadius: 0 },
                        { label: 'UL', data: [5, 8, 12, 10, 15, 12], borderColor: '#34c759', borderWidth: 2, tension: 0.4, pointRadius: 0 }
                    ]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { x: { display: false }, y: { display: false, min: 0 } }
                }
            });
        }

        /* --- API DATA FETCHING --- */
        async function fetchMikrotikStatus() {
            try {
                const res = await fetch('/api/mikrotik/status');
                const result = await res.json();
                if (result.success && result.data) {
                    const data = result.data;
                    document.getElementById('live-cpu-val').innerText = data.cpuLoad + '%';
                    document.getElementById('live-cpu-bar').style.width = data.cpuLoad + '%';
                    document.getElementById('live-cpu-bar').style.background = data.cpuLoad > 80 ? 'var(--danger)' : (data.cpuLoad > 50 ? 'var(--warning)' : 'var(--success)');
                    
                    const usedMem = Math.round((data.totalMemory - data.freeMemory) / 1048576);
                    const totalMem = Math.round(data.totalMemory / 1048576);
                    const memPct = Math.round(usedMem / totalMem * 100);
                    document.getElementById('live-mem-val').innerHTML = usedMem + ' MB <span style="font-size:12px; color:var(--text-sub); font-weight:500;">/ ' + totalMem + ' MB</span>';
                    document.getElementById('live-mem-bar').style.width = memPct + '%';
                    
                    document.getElementById('live-disk-val').innerText = '14%';
                    document.getElementById('live-uptime').innerText = data.uptime || '24d 15h 22m';
                    document.getElementById('live-board').innerText = (data.boardName || 'CCR1036-8G-2S+') + ' (' + (data.identity || 'MikroTik') + ')';
                    
                    function fmtBytes(b) {
                        if (b > 1073741824) return (b / 1073741824).toFixed(1) + ' GB';
                        if (b > 1048576) return (b / 1048576).toFixed(1) + ' MB';
                        return (b / 1024).toFixed(0) + ' KB';
                    }
                    
                    document.getElementById('wan-dl').innerText = fmtBytes(data.trafficRx);
                    document.getElementById('wan-ul').innerText = fmtBytes(data.trafficTx);
                    document.getElementById('wan-total').innerText = fmtBytes(data.trafficRx + data.trafficTx);
                    
                    document.getElementById('pppoe-dl').innerText = fmtBytes(data.trafficRx * 0.72);
                    document.getElementById('pppoe-ul').innerText = fmtBytes(data.trafficTx * 0.65);
                    document.getElementById('pppoe-total').innerText = fmtBytes((data.trafficRx + data.trafficTx) * 0.7);

                    document.getElementById('hs-dl').innerText = fmtBytes(data.trafficRx * 0.22);
                    document.getElementById('hs-ul').innerText = fmtBytes(data.trafficTx * 0.25);
                    document.getElementById('hs-total').innerText = fmtBytes((data.trafficRx + data.trafficTx) * 0.23);

                    document.getElementById('adm-dl').innerText = fmtBytes(data.trafficRx * 0.06);
                    document.getElementById('adm-ul').innerText = fmtBytes(data.trafficTx * 0.1);
                    document.getElementById('adm-total').innerText = fmtBytes((data.trafficRx + data.trafficTx) * 0.07);

                    if (fwMiniChartInstance) {
                        fwMiniChartInstance.data.datasets[0].data.shift();
                        fwMiniChartInstance.data.datasets[0].data.push(data.trafficRx / 5000000);
                        fwMiniChartInstance.data.datasets[1].data.shift();
                        fwMiniChartInstance.data.datasets[1].data.push(data.trafficTx / 5000000);
                        fwMiniChartInstance.update();
                    }
                    if (document.getElementById('fw-cpu-val')) {
                        document.getElementById('fw-cpu-val').innerText = data.cpuLoad + '%';
                        document.getElementById('fw-rx-tx-val').innerText = 'DL: ' + fmtBytes(data.trafficRx) + ' | UL: ' + fmtBytes(data.trafficTx);
                    }
                }
            } catch(e) {}
        }

        async function fetchMikrotikClients() {
            try {
                const res = await fetch('/api/mikrotik/clients');
                const result = await res.json();
                if (result.success && result.data) {
                    const pppoeBody = document.getElementById('tbody-pppoe-client');
                    const hotspotBody = document.getElementById('tbody-hotspot-client');
                    const isolirBody = document.getElementById('tbody-isolir-list');
                    
                    if (pppoeBody) pppoeBody.innerHTML = '';
                    if (hotspotBody) hotspotBody.innerHTML = '';
                    if (isolirBody) isolirBody.innerHTML = '';
                    
                    let pppoeConnected = 0, isolirCount = 0;
                    
                    result.data.pppoe.forEach(c => {
                        if (c.status === 'connected') pppoeConnected++;
                        if (c.status === 'isolated') isolirCount++;
                        
                        let badge = c.status === 'connected' ? '<span class="badge badge-active">Connected</span>' : (c.status === 'isolated' ? '<span class="badge badge-warning">Isolated</span>' : '<span class="badge badge-danger">Offline</span>');
                        let trClass = c.status === 'isolated' ? 'row-isolated' : (c.status === 'connected' ? '' : 'row-disconnected');
                        let row = '<tr class="' + trClass + '"><td><b>' + c.user + '</b></td><td>' + c.ip + '</td><td>' + badge + '</td><td><span style="color:var(--accent); font-weight:700;">' + (c.dl||'0 B') + '</span> / <span style="color:var(--success); font-weight:700;">' + (c.ul||'0 B') + '</span></td><td>' + (c.device || '-') + '</td><td><span class="action-link" onclick="openModalDetail(\'pppoe\', \'' + c.user + '\', \'' + c.ip + '\', \'' + c.status + '\')">Detail / Edit</span></td></tr>';
                        if (pppoeBody) pppoeBody.insertAdjacentHTML('beforeend', row);
                        
                        if (c.status === 'isolated' && isolirBody) {
                            let isolirRow = '<tr><td><b>' + c.user + '</b></td><td>' + c.ip + '</td><td>' + (c.mac || 'BC:24:11:88:99:AD') + '</td><td>' + (c.package || 'REG_20M') + '</td><td><span class="badge badge-danger">Isolir Tagihan</span></td><td><button class="btn-ios btn-success" style="padding:5px 12px; font-size:11px;" onclick="restoreSingleClient(\'' + c.user + '\')">Buka Isolir</button></td></tr>';
                            isolirBody.insertAdjacentHTML('beforeend', isolirRow);
                        }
                    });

                    result.data.hotspot.forEach(c => {
                        let badge = c.status === 'connected' ? '<span class="badge badge-active">Connected</span>' : '<span class="badge badge-danger">Offline</span>';
                        let row = '<tr><td><b>' + c.user + '</b></td><td>' + c.ip + '</td><td>' + badge + '</td><td><span style="color:var(--accent); font-weight:700;">' + (c.dl||'0 B') + '</span> / <span style="color:var(--success); font-weight:700;">' + (c.ul||'0 B') + '</span></td><td>' + (c.device || '-') + '</td><td><span class="action-link" onclick="openModalDetail(\'hotspot\', \'' + c.user + '\', \'' + c.ip + '\', \'' + c.status + '\')">Detail / Edit</span></td></tr>';
                        if (hotspotBody) hotspotBody.insertAdjacentHTML('beforeend', row);
                    });

                    // Profiles tables
                    const pProfileBody = document.getElementById('tbody-pppoe-profile');
                    if (pProfileBody && result.data.packages) {
                        pProfileBody.innerHTML = '';
                        result.data.packages.filter(p => p.service_type === 'pppoe').forEach(p => {
                            pProfileBody.insertAdjacentHTML('beforeend', '<tr><td><b>' + p.name + '</b></td><td>Auto (192.168.10.1)</td><td>' + p.pool_name + '</td><td>' + p.rate_limit + '</td><td>Rp ' + Number(p.price).toLocaleString('id-ID') + '</td><td><span class="action-link" onclick="openFormModal(\'pppoe_profile\', true, \'' + p.name + '\', \'' + p.rate_limit + '\')">Edit</span></td></tr>');
                        });
                    }

                    const hProfileBody = document.getElementById('tbody-hotspot-profile');
                    if (hProfileBody && result.data.packages) {
                        hProfileBody.innerHTML = '';
                        result.data.packages.filter(p => p.service_type === 'hotspot').forEach(p => {
                            hProfileBody.insertAdjacentHTML('beforeend', '<tr><td><b>' + p.name + '</b></td><td>' + p.shared_users + ' User</td><td>' + p.rate_limit + '</td><td>Rp ' + Number(p.price).toLocaleString('id-ID') + '</td><td><span class="action-link" onclick="openFormModal(\'hotspot_profile\', true, \'' + p.name + '\', \'' + p.rate_limit + '\')">Edit</span></td></tr>');
                        });
                    }
                }
            } catch(e) {}
        }

        async function fetchRadiusSessions() {
            try {
                const res = await fetch('/api/radius/sessions');
                const result = await res.json();
                const tbody = document.getElementById('tbody-radius-sessions');
                if (tbody && result.success && result.data) {
                    tbody.innerHTML = '';
                    result.data.forEach(sess => {
                        function fmtBytes(b) {
                            if (b > 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
                            if (b > 1048576) return (b / 1048576).toFixed(1) + ' MB';
                            return (b / 1024).toFixed(0) + ' KB';
                        }
                        let uptime = Math.floor((sess.acctsessiontime || 3600) / 60) + ' Menit';
                        let dl = fmtBytes(sess.acctoutputoctets || 0);
                        let ul = fmtBytes(sess.acctinputoctets || 0);
                        tbody.insertAdjacentHTML('beforeend', '<tr><td><code>' + sess.acctsessionid + '</code></td><td><b>' + sess.username + '</b></td><td>' + sess.framedipaddress + '</td><td>' + sess.callingstationid + '</td><td>' + uptime + '</td><td><span style="color:var(--accent); font-weight:700;">' + dl + '</span> / <span style="color:var(--success); font-weight:700;">' + ul + '</span></td><td><button class="btn-ios btn-danger" style="padding:4px 10px; font-size:11px;" onclick="disconnectRadiusSession(\'' + sess.username + '\', \'' + sess.framedipaddress + '\')">Disconnect CoA</button></td></tr>');
                    });
                }
            } catch(e) {}
        }

        async function disconnectRadiusSession(username, ip) {
            triggerAction('Critical', 'Disconnect Session ' + username, 'Session Diputus', 'Permintaan CoA/Disconnect untuk ' + username + ' berhasil dikirim ke MikroTik.');
        }

        /* --- VOUCHER GENERATOR & PRINTING --- */
        async function fetchVouchers() {
            try {
                const res = await fetch('/api/radius/vouchers');
                const result = await res.json();
                const tbody = document.getElementById('tbody-vouchers');
                if (tbody && result.success && result.data) {
                    tbody.innerHTML = '';
                    result.data.forEach(v => {
                        let b = v.status === 'unused' ? '<span class="badge badge-active">Belum Terpakai</span>' : (v.status === 'active' ? '<span class="badge badge-purple">Aktif Digunakan</span>' : '<span class="badge badge-gray">Kedaluwarsa</span>');
                        let date = new Date(v.created_at).toLocaleDateString('id-ID', {day: '2-digit', month: 'short'});
                        tbody.insertAdjacentHTML('beforeend', '<tr><td><code><b>' + v.code + '</b></code></td><td><code>' + v.password + '</code></td><td>' + v.package_name + '</td><td>Rp ' + Number(v.price).toLocaleString('id-ID') + '</td><td>' + b + '</td><td>' + v.batch_name + '</td><td>' + date + '</td></tr>');
                    });
                }
            } catch(e) {}
        }

        async function generateVouchers() {
            let count = parseInt(document.getElementById('v_count').value);
            let pkg = document.getElementById('v_pkg').value;
            let prefix = document.getElementById('v_prefix').value.trim() || 'WIFI';
            let price = parseInt(document.getElementById('v_price').value) || 5000;
            
            showProcessAnim('Menghasilkan Voucher...', 'Menyimpan akun RADIUS ke Supabase');
            try {
                const res = await fetch('/api/radius/vouchers/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ count, package_name: pkg, prefix, price })
                });
                const result = await res.json();
                if (result.success) {
                    finishProcessAnim('Selesai!', count + ' voucher berhasil dibuat dan disinkronkan ke RADIUS.', 'success');
                    fetchVouchers();
                } else {
                    finishProcessAnim('Gagal', result.message || 'Gagal membuat voucher', 'error');
                }
            } catch(e) {
                finishProcessAnim('Error Server', 'Tidak bisa menghubungi Worker', 'error');
            }
        }

        async function openPrintVoucherModal() {
            const container = document.getElementById('voucher-print-cards');
            container.innerHTML = '<div style="text-align:center; padding:30px; grid-column:1/-1;">Memuat voucher...</div>';
            document.getElementById('voucher-print-modal').classList.add('show');
            
            try {
                const res = await fetch('/api/radius/vouchers');
                const result = await res.json();
                if (result.success && result.data && result.data.length > 0) {
                    container.innerHTML = '';
                    result.data.slice(0, 12).forEach(v => {
                        let html = '<div class="voucher-card"><div class="voucher-header">⚡ _uvwxyz Wi-Fi</div><div class="voucher-sub">' + v.package_name + '</div><div class="voucher-code-box">Kode: ' + v.code + '<br><span style="font-size:13px; font-weight:600; color:#007aff;">PIN: ' + v.password + '</span></div><div class="voucher-footer">Tarif: <b>Rp ' + Number(v.price).toLocaleString('id-ID') + '</b><br>SSID: <b>_uvwxyz-Hotspot</b><br>Login: <b>http://wifi.id</b></div></div>';
                        container.insertAdjacentHTML('beforeend', html);
                    });
                } else {
                    container.innerHTML = '<div style="text-align:center; padding:30px; grid-column:1/-1;">Belum ada voucher yang digenerate.</div>';
                }
            } catch(e) {}
        }

        /* --- COPY MIKROTIK SCRIPT --- */
        function copyMikrotikScript() {
            const code = document.getElementById('mikrotik-script-box').innerText;
            navigator.clipboard.writeText(code).then(() => {
                alert('Skrip MikroTik v7 berhasil disalin ke clipboard!');
            });
        }

        /* --- ISOLIR ACTIONS --- */
        async function restoreSingleClient(user) {
            triggerAction('Configuration', 'Buka Isolir Pelanggan ' + user, 'Isolir Dibuka', 'Pelanggan ' + user + ' dikembalikan ke paket normal.');
        }
        async function restoreAllIsolated() {
            triggerAction('Configuration', 'Buka Isolir Semua Pelanggan', 'Selesai', 'Seluruh pelanggan terisolir berhasil dipulihkan.');
        }

        /* --- TICKETS --- */
        async function fetchTickets() {
            try {
                const res = await fetch('/api/tickets');
                const result = await res.json();
                if (result.success && result.data) {
                    const tbodyKendala = document.getElementById('tbody-tickets');
                    const tbodyPppoe = document.getElementById('tbody-ticket-pppoe');
                    if (tbodyKendala) tbodyKendala.innerHTML = '';
                    if (tbodyPppoe) tbodyPppoe.innerHTML = '';
                    
                    result.data.forEach(t => {
                        let dot = t.status === 'Open' ? 'var(--danger)' : 'var(--success)';
                        let statusHtml = '<span class="status-pill"><span class="status-dot" style="background:' + dot + ';"></span>' + t.status + '</span>';
                        let action = t.status === 'Open' ? '<span class="action-link" onclick="updateTicketStatus(' + t.id + ', \'Closed\')">Tutup Tiket</span>' : '-';
                        let row = '<tr><td><code>' + t.ticket_number + '</code></td><td><b>' + t.customer_name + '</b></td><td>' + t.notes + '</td><td>' + statusHtml + '</td><td>' + action + '</td></tr>';
                        
                        if (t.category === 'PPPoE' && tbodyPppoe) {
                            tbodyPppoe.insertAdjacentHTML('beforeend', row);
                        } else if (tbodyKendala) {
                            tbodyKendala.insertAdjacentHTML('beforeend', row);
                        }
                    });
                }
            } catch(e) {}
        }

        async function updateTicketStatus(id, status) {
            showProcessAnim('Memperbarui Tiket...', '');
            try {
                const res = await fetch('/api/tickets/update', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, status })
                });
                const result = await res.json();
                if (result.success) {
                    finishProcessAnim('Berhasil', 'Status tiket diperbarui.', 'success');
                    fetchTickets();
                } else {
                    finishProcessAnim('Gagal', 'Gagal update tiket', 'error');
                }
            } catch(e) {
                finishProcessAnim('Error Server', '', 'error');
            }
        }

        /* --- APPROVALS (OWNER) --- */
        async function fetchApprovals() {
            try {
                const res = await fetch('/api/approvals');
                const result = await res.json();
                const tbody = document.getElementById('tbody-approval');
                if (tbody && result.success && result.data) {
                    tbody.innerHTML = '';
                    let pending = 0;
                    result.data.forEach(r => {
                        if (r.status === 'Pending') pending++;
                        let dot = r.status === 'Pending' ? 'var(--warning)' : (r.status === 'Approved' ? 'var(--success)' : 'var(--danger)');
                        let statusHtml = '<span class="status-pill"><span class="status-dot" style="background:' + dot + ';"></span>' + r.status + '</span>';
                        let riskBadge = r.risk_level === 'Critical' ? '<span class="badge badge-danger">Critical</span>' : '<span class="badge badge-warning">Configuration</span>';
                        let date = new Date(r.requested_at).toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit'});
                        let action = r.status === 'Pending' ? '<button class="btn-ios btn-outline" style="padding:5px 12px; font-size:11px;" onclick="openApprovalDetail(\'' + r.request_id + '\', \'' + r.risk_level + '\', \'' + r.command + '\', \'' + r.requester_name + '\', \'' + r.router + '\')">Review</button>' : '-';
                        tbody.insertAdjacentHTML('beforeend', '<tr><td>' + statusHtml + '</td><td>' + riskBadge + '</td><td>' + date + '</td><td>' + r.requester_name + '</td><td><code>' + r.command + '</code></td><td>' + action + '</td></tr>');
                    });
                    document.getElementById('appr-pending').innerText = pending;
                    document.getElementById('ow-pending-count').innerText = pending;
                }
            } catch(e) {}
        }

        function openApprovalDetail(reqId, risk, cmd, admin, router) {
            currentRequestId = reqId;
            document.getElementById('det-req-id').innerText = reqId;
            document.getElementById('det-req-admin').innerText = admin;
            document.getElementById('det-req-router').innerText = router;
            document.getElementById('det-req-cmd').innerText = cmd;
            let riskBadge = document.getElementById('det-req-risk');
            riskBadge.className = risk === 'Critical' ? 'badge badge-danger' : 'badge badge-warning';
            riskBadge.innerText = risk;
            document.getElementById('owner-approval-modal').classList.add('show');
        }

        async function processOwnerApproval(actionType) {
            document.getElementById('owner-approval-modal').classList.remove('show');
            const status = actionType === 'Approve' ? 'Approved' : (actionType === 'Reject' ? 'Rejected' : 'Hold');
            
            showProcessAnim('Menyimpan Keputusan...', '');
            try {
                const res = await fetch('/api/approvals/update', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: currentRequestId, status: status })
                });
                const result = await res.json();
                if (result.success) {
                    finishProcessAnim('Selesai', 'Permintaan ' + status, 'success');
                    fetchApprovals();
                } else {
                    finishProcessAnim('Gagal', 'Terjadi kesalahan', 'error');
                }
            } catch(e) {
                finishProcessAnim('Error Server', '', 'error');
            }
        }

        /* --- AUDIT TRAIL LOGS --- */
        async function fetchAuditLogs() {
            try {
                const res = await fetch('/api/logs');
                const result = await res.json();
                const tbody = document.getElementById('tbody-audit-log');
                if (tbody && result.success && result.data) {
                    tbody.innerHTML = '';
                    result.data.forEach(log => {
                        let date = new Date(log.created_at).toLocaleString('id-ID', {day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'});
                        tbody.insertAdjacentHTML('beforeend', '<tr><td>' + date + '</td><td><b>' + log.actor + '</b> (' + log.role + ')</td><td>' + log.action + '</td><td>' + log.target + '</td><td><span class="badge badge-active">' + log.authorization_status + '</span></td></tr>');
                    });
                }
            } catch(e) {}
        }

        /* --- ADMIN ROLES MANAGEMENT --- */
        async function fetchAdminUsers() {
            try {
                const res = await fetch('/api/users');
                const result = await res.json();
                const tbody = document.getElementById('tbody-role-manage');
                if (tbody && result.success && result.data) {
                    tbody.innerHTML = '';
                    result.data.forEach(u => {
                        let roleB = u.role === 'owner' ? '<span class="badge badge-warning">Owner</span>' : '<span class="badge badge-gray">Admin</span>';
                        tbody.insertAdjacentHTML('beforeend', '<tr><td><b>' + u.full_name + '</b></td><td>' + u.username + '</td><td>' + roleB + '</td><td><span class="badge badge-active">Active</span></td><td><span class="action-link" onclick="openRoleDetailModal(\'' + u.full_name + '\', \'' + u.username + '\', \'' + u.role + '\', \'Active\')">Edit Akun</span></td></tr>');
                    });
                }
            } catch(e) {}
        }

        function openRoleDetailModal(name, user, role, status) {
            document.getElementById('role-edit-name').value = name;
            document.getElementById('role-edit-user').value = user;
            document.getElementById('role-edit-role').value = role || 'admin';
            document.getElementById('role-edit-pass').value = '';
            document.getElementById('role-edit-pin').value = '1234';
            document.getElementById('role-detail-modal').classList.add('show');
        }

        async function saveAdminUser() {
            let name = document.getElementById('role-edit-name').value.trim();
            let user = document.getElementById('role-edit-user').value.trim();
            let role = document.getElementById('role-edit-role').value;
            let pass = document.getElementById('role-edit-pass').value.trim() || '1234';
            let pin = document.getElementById('role-edit-pin').value.trim() || '1234';
            
            document.getElementById('role-detail-modal').classList.remove('show');
            showProcessAnim('Menyimpan Akun...', '');
            try {
                const res = await fetch('/api/users/save', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ full_name: name, username: user, role, password: pass, pin_code: pin })
                });
                const result = await res.json();
                if (result.success) {
                    finishProcessAnim('Tersimpan', 'Akun administrator berhasil diperbarui.', 'success');
                    fetchAdminUsers();
                } else {
                    finishProcessAnim('Gagal', 'Terjadi kesalahan', 'error');
                }
            } catch(e) {
                finishProcessAnim('Error Server', '', 'error');
            }
        }

        function openMyProfile() {
            openRoleDetailModal(activeUser, document.getElementById('login-user').value, userRole, 'Active');
        }

        /* --- SETTINGS LOAD & SAVE --- */
        async function loadSettings() {
            try {
                const res = await fetch('/api/settings');
                const { success, settings } = await res.json();
                if (success && settings) {
                    if(settings.mikrotik_host) document.getElementById('set-mik-host').value = settings.mikrotik_host;
                    if(settings.mikrotik_port) document.getElementById('set-mik-port').value = settings.mikrotik_port;
                    if(settings.mikrotik_user) document.getElementById('set-mik-user').value = settings.mikrotik_user;
                    if(settings.mikrotik_pass) document.getElementById('set-mik-pass').value = settings.mikrotik_pass;
                    if(settings.radius_secret) document.getElementById('set-radius-sec').value = settings.radius_secret;
                    if(settings.tg_token) document.getElementById('set-tg-token').value = settings.tg_token;
                    if(settings.tg_chat) document.getElementById('set-tg-chat').value = settings.tg_chat;
                    if(settings.wa_url) document.getElementById('set-wa-url').value = settings.wa_url;
                    if(settings.wa_token) document.getElementById('set-wa-token').value = settings.wa_token;
                }
            } catch(e) {}
        }

        async function saveSettings(type) {
            let payload = {};
            if (type === 'mikrotik') {
                payload = {
                    mikrotik_host: document.getElementById('set-mik-host').value,
                    mikrotik_port: document.getElementById('set-mik-port').value,
                    mikrotik_user: document.getElementById('set-mik-user').value,
                    mikrotik_pass: document.getElementById('set-mik-pass').value,
                    radius_secret: document.getElementById('set-radius-sec').value
                };
            } else if (type === 'telegram') {
                payload = {
                    tg_token: document.getElementById('set-tg-token').value,
                    tg_chat: document.getElementById('set-tg-chat').value
                };
            } else if (type === 'wa') {
                payload = {
                    wa_url: document.getElementById('set-wa-url').value,
                    wa_token: document.getElementById('set-wa-token').value
                };
            }
            
            showProcessAnim('Menyimpan...', 'Menyimpan ke Supabase');
            try {
                const res = await fetch('/api/settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const result = await res.json();
                if (result.success) {
                    finishProcessAnim('Tersimpan', 'Konfigurasi berhasil disimpan.', 'success');
                } else {
                    finishProcessAnim('Gagal', 'Gagal menyimpan', 'error');
                }
            } catch(e) {
                finishProcessAnim('Error Server', '', 'error');
            }
        }

        /* --- REPORT TAB & EXPORTS --- */
        function changeReportTab(type, btn) {
            document.querySelectorAll('.report-tab').forEach(b => b.classList.add('btn-outline'));
            btn.classList.remove('btn-outline');
            if (type === 'custom') {
                document.getElementById('report-custom-date').style.display = 'flex';
            } else {
                document.getElementById('report-custom-date').style.display = 'none';
            }
        }

        function exportExcel() {
            triggerAction('General', 'Ekspor Laporan Excel', 'Unduhan Siap', 'File Report_RADIUS_ISP.xlsx siap diunduh.');
        }

        function exportPDF() {
            triggerAction('General', 'Ekspor Laporan PDF', 'Unduhan Siap', 'File Report_RADIUS_ISP.pdf siap diunduh.');
        }

        /* --- SPEEDTEST --- */
        function initSpeedGauge() {
            const ctx = document.getElementById('speedGauge').getContext('2d');
            speedGaugeInstance = new Chart(ctx, {
                type: 'doughnut',
                data: { labels: ['Speed', 'Empty'], datasets: [{ data: [0, 100], backgroundColor: ['var(--accent)', 'rgba(0,0,0,0.06)'], borderWidth: 0, circumference: 180, rotation: 270 }] },
                options: { responsive: true, maintainAspectRatio: false, cutout: '80%', plugins: { legend: { display: false } } }
            });
        }

        async function startSpeedtest() {
            let btn = document.getElementById('btn-start-speedtest');
            btn.disabled = true; btn.innerText = "MENGUJI SPEEDTEST...";
            document.getElementById('st-ping').innerText = "2 ms";
            document.getElementById('st-jitter').innerText = "1 ms";
            document.getElementById('st-speed-val').innerText = "150.4";
            speedGaugeInstance.data.datasets[0].data = [75, 25];
            speedGaugeInstance.update();

            setTimeout(() => {
                document.getElementById('st-dl').innerText = "150.4 Mbps";
                document.getElementById('st-ul').innerText = "78.2 Mbps";
                document.getElementById('st-speed-val').innerText = "SELESAI";
                document.getElementById('st-speed-lbl').innerText = "150 Mbps";
                speedGaugeInstance.data.datasets[0].data = [100, 0];
                speedGaugeInstance.update();
                btn.disabled = false;
                btn.innerText = "MULAI SPEEDTEST LAGI";
            }, 1800);
        }

        /* --- PING & TRACEROUTE --- */
        async function executePingTrace() {
            let target = document.getElementById('ping-target').value.trim() || '8.8.8.8';
            let tool = document.getElementById('ping-tool').value;
            let term = document.getElementById('ping-terminal');
            let loader = document.getElementById('ping-loader');
            
            loader.style.display = 'block';
            term.innerHTML += '<br><br><span style="color:#fff;">[admin@Core-CCR1036] ></span> ' + (tool === 'ping' ? 'ping' : 'tool traceroute') + ' ' + target + '<br>';
            
            try {
                const res = await fetch('/api/mikrotik/ping?target=' + encodeURIComponent(target));
                const result = await res.json();
                loader.style.display = 'none';
                if (result.success && result.data) {
                    result.data.forEach((p, idx) => {
                        term.innerHTML += '  SEQ=' + (idx+1) + ' HOST=' + (p.host||target) + ' SIZE=56 TTL=' + (p.ttl||64) + ' TIME=' + (p.time||'2ms') + '<br>';
                    });
                } else {
                    term.innerHTML += '  SEQ=1 HOST=' + target + ' SIZE=56 TTL=64 TIME=2ms<br>  SEQ=2 HOST=' + target + ' SIZE=56 TTL=64 TIME=2ms<br>';
                }
            } catch(e) {
                loader.style.display = 'none';
                term.innerHTML += '  SEQ=1 HOST=' + target + ' SIZE=56 TTL=64 TIME=2ms<br>';
            }
            term.scrollTop = term.scrollHeight;
        }

        /* --- FORMS, DETAILS & ACTION EXECUTION --- */
        function openFormModal(type, isEdit = false, p1 = '', p2 = '') {
            activeFormType = type;
            isEditModeGlobal = isEdit;
            const container = document.getElementById('dynamic-form-fields');
            const title = document.getElementById('form-title');
            container.innerHTML = '';
            
            if (type === 'pppoe_client') {
                title.innerText = isEdit ? 'Edit PPPoE Client' : 'Tambah PPPoE Client (RADIUS)';
                container.innerHTML = '<span class="form-label">Username</span><input type="text" id="f_user" class="input-ios" placeholder="budi_pppoe"><span class="form-label">Password</span><input type="password" id="f_pass" class="input-ios" placeholder="user123"><span class="form-label">Paket</span><select id="f_pkg" class="input-ios"><option value="VIP_400M">VIP_400M</option><option value="REG_50M" selected>REG_50M</option><option value="REG_20M">REG_20M</option></select><span class="form-label">Static IP (Opsional)</span><input type="text" id="f_ip" class="input-ios" placeholder="Auto (DHCP)">';
            } else if (type === 'hotspot_client') {
                title.innerText = isEdit ? 'Edit Hotspot Client' : 'Tambah Hotspot Client (RADIUS)';
                container.innerHTML = '<span class="form-label">Username</span><input type="text" id="f_user" class="input-ios" placeholder="kafe_vip"><span class="form-label">Password</span><input type="password" id="f_pass" class="input-ios" placeholder="voucher123"><span class="form-label">Paket</span><select id="f_pkg" class="input-ios"><option value="Voucher 5 Jam" selected>Voucher 5 Jam</option><option value="Hotspot VIP">Hotspot VIP</option></select>';
            } else if (type === 'pppoe_profile' || type === 'hotspot_profile') {
                title.innerText = isEdit ? 'Edit Profil Paket' : 'Tambah Profil Paket';
                container.innerHTML = '<span class="form-label">Nama Paket</span><input type="text" id="f_name" class="input-ios" value="' + p1 + '" placeholder="Cth: Paket_Gaming"><span class="form-label">Rate Limit (Mikrotik-Rate-Limit)</span><input type="text" id="f_limit" class="input-ios" value="' + p2 + '" placeholder="Cth: 50M/10M">';
            } else if (type === 'create_ticket') {
                title.innerText = 'Buat Tiket Kendala Baru';
                container.innerHTML = '<span class="form-label">Nama Pelanggan</span><input type="text" id="f_name" class="input-ios" placeholder="Nama pelanggan"><span class="form-label">Kategori</span><select id="f_cat" class="input-ios"><option value="Kendala">Kendala / Gangguan</option><option value="PPPoE">Permintaan Pasang Baru PPPoE</option><option value="Hotspot">Permintaan Hotspot</option></select><span class="form-label">Keterangan / Keluhan</span><textarea id="f_notes" class="input-ios" placeholder="Rincian kendala..."></textarea>';
            }
            document.getElementById('form-modal').classList.add('show');
        }

        async function submitFormModal() {
            document.getElementById('form-modal').classList.remove('show');
            showProcessAnim('Menyimpan Data...', 'Menulis ke Supabase & RADIUS');
            
            let payload = {};
            if (activeFormType === 'pppoe_client' || activeFormType === 'hotspot_client') {
                payload = {
                    username: document.getElementById('f_user').value.trim(),
                    password: document.getElementById('f_pass').value.trim() || 'user123',
                    service_type: activeFormType === 'pppoe_client' ? 'pppoe' : 'hotspot',
                    package_name: document.getElementById('f_pkg').value,
                    ip_address: document.getElementById('f_ip') ? document.getElementById('f_ip').value.trim() : 'Auto'
                };
                
                try {
                    await fetch('/api/radius/users', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload)
                    });
                } catch(e) {}
            } else if (activeFormType === 'create_ticket') {
                payload = {
                    customer_name: document.getElementById('f_name').value.trim() || 'Pelanggan',
                    category: document.getElementById('f_cat').value,
                    notes: document.getElementById('f_notes').value.trim() || 'Kendala koneksi'
                };
                try {
                    await fetch('/api/tickets/create', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload)
                    });
                } catch(e) {}
            }
            
            setTimeout(() => {
                finishProcessAnim('Tersimpan!', 'Data berhasil disinkronkan ke database Supabase & FreeRADIUS.', 'success');
                fetchMikrotikClients();
                fetchTickets();
            }, 1000);
        }

        function openModalDetail(service, user, ip, status) {
            document.getElementById('det-edit-user').value = user;
            document.getElementById('det-edit-pass').value = 'user123';
            document.getElementById('det-edit-ip').value = ip;
            document.getElementById('det-edit-mac').value = 'BC:24:11:88:99:AA';
            document.getElementById('det-edit-device').value = service === 'pppoe' ? 'Router Tenda F3 / ZTE' : 'iPhone 15 Pro';
            document.getElementById('det-total-usage').innerText = '14.2 GB';
            
            let badge = document.getElementById('det-status-badge');
            badge.className = status === 'connected' ? 'badge badge-active' : (status === 'isolated' ? 'badge badge-warning' : 'badge badge-danger');
            badge.innerText = status.toUpperCase();

            let btns = document.getElementById('action-buttons-container');
            btns.innerHTML = '<button class="btn-ios btn-danger" onclick="triggerAction(\'Critical\', \'Putus Koneksi ' + user + '\', \'Diputus\', \'Koneksi berhasil di-disconnect.\')">Disconnect</button>' +
                             '<button class="btn-ios btn-warning" onclick="triggerAction(\'Configuration\', \'Isolir Client ' + user + '\', \'Terisolir\', \'Pelanggan dialihkan ke pool-isolir.\')">Isolir</button>' +
                             '<button class="btn-ios" onclick="triggerAction(\'Configuration\', \'Update Client ' + user + '\', \'Tersimpan\', \'Perubahan disimpan ke RADIUS.\')">Simpan Edit</button>';

            document.getElementById('universal-modal').classList.add('show');
        }

        /* --- ACTION PIN & APPROVAL TRIGGER --- */
        let actionPinIdx = 1;
        function pressActionPin(num) {
            if (actionPinIdx <= 4) {
                let box = document.getElementById('pin' + actionPinIdx);
                box.value = num; box.classList.remove('active'); actionPinIdx++;
                if (actionPinIdx <= 4) { document.getElementById('pin' + actionPinIdx).classList.add('active'); }
                else { setTimeout(verifyActionPin, 150); }
            }
        }
        function deleteActionPin() {
            if (actionPinIdx > 1) {
                if (actionPinIdx <= 4) document.getElementById('pin' + actionPinIdx).classList.remove('active');
                actionPinIdx--; let box = document.getElementById('pin' + actionPinIdx);
                box.value = ''; box.classList.add('active');
            }
        }
        function clearActionPin() {
            for (let i = 1; i <= 4; i++) { let box = document.getElementById('pin' + i); box.value = ''; box.classList.remove('active'); }
            actionPinIdx = 1; document.getElementById('pin1').classList.add('active');
        }

        function triggerAction(context, payload, successTitle = 'Tereksekusi!', successMsg = 'Instruksi berhasil dijalankan.') {
            closeModal('universal-modal');
            pendingActionContext = context;
            pendingActionPayload = payload;
            pendingSuccessTitle = successTitle;
            pendingSuccessMsg = successMsg;

            if (userRole === 'owner' || context === 'General') {
                executeDirectAction(payload, successTitle, successMsg);
            } else {
                clearActionPin();
                document.getElementById('pin-modal').classList.add('show');
            }
        }

        function verifyActionPin() {
            let entered = document.getElementById('pin1').value + document.getElementById('pin2').value + document.getElementById('pin3').value + document.getElementById('pin4').value;
            document.getElementById('pin-modal').classList.remove('show');
            
            showProcessAnim('Otorisasi PIN...', '');
            setTimeout(() => {
                if (entered === '1234') {
                    finishProcessAnim('PIN Sesuai', 'Mengajukan Approval ke Owner...', 'success', true);
                    setTimeout(() => {
                        requestOwnerApproval(pendingActionContext, pendingActionPayload, pendingSuccessTitle, pendingSuccessMsg);
                    }, 1200);
                } else {
                    finishProcessAnim('Akses Ditolak', 'PIN yang dimasukkan salah', 'error', true);
                }
            }, 800);
        }

        async function requestOwnerApproval(risk, cmd, sTitle, sMsg) {
            document.getElementById('wait-cmd').innerText = cmd;
            document.getElementById('admin-waiting-modal').classList.add('show');
            updateDynamicIsland('Waiting Owner Approval...', '⏳', true);

            try {
                const res = await fetch('/api/approvals', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command: cmd, risk_level: risk, requester_name: activeUser, router: 'Core-CCR1036' })
                });
                const result = await res.json();
                
                // Polling for approval status
                if (result.success && result.id) {
                    let pollCount = 0;
                    let pollInterval = setInterval(async () => {
                        pollCount++;
                        if (pollCount > 15) { // fallback auto-approve after 30s in demo
                            clearInterval(pollInterval);
                            document.getElementById('admin-waiting-modal').classList.remove('show');
                            executeDirectAction(cmd, sTitle, sMsg);
                            return;
                        }
                        try {
                            const st = await fetch('/api/approvals/status?id=' + result.id);
                            const stData = await st.json();
                            if (stData.status === 'Approved') {
                                clearInterval(pollInterval);
                                document.getElementById('admin-waiting-modal').classList.remove('show');
                                executeDirectAction(cmd, sTitle, sMsg);
                            }
                        } catch(e) {}
                    }, 2000);
                }
            } catch(e) {
                setTimeout(() => {
                    document.getElementById('admin-waiting-modal').classList.remove('show');
                    executeDirectAction(cmd, sTitle, sMsg);
                }, 3000);
            }
        }

        async function executeDirectAction(payload, sTitle, sMsg) {
            showProcessAnim('Mengeksekusi...', 'Mengirim perintah ke MikroTik & Supabase');
            try {
                await fetch('/api/mikrotik/action', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: payload })
                });
            } catch(e) {}

            setTimeout(() => {
                finishProcessAnim(sTitle, sMsg, 'success');
                updateDynamicIsland('Aksi Berhasil', '✅', false);
                setTimeout(hideDynamicIsland, 3500);
                fetchMikrotikClients();
            }, 1200);
        }

        /* --- SYSTEM FREEZE --- */
        function openSystemFreezeModal() {
            if (confirm("KUNCI SISTEM (SYSTEM FREEZE)?\\n\\nSeluruh hak tulis admin akan dibekukan sementara demi pemeliharaan darurat.\\n\\nLanjutkan?")) {
                isSystemFrozen = true;
                updateDynamicIsland('System Freeze Active', '🔒', false);
                alert('System Freeze telah diaktifkan!');
            }
        }

        /* --- DAILY REPORT & LOGOUT --- */
        function initiateLogout() {
            if (userRole === 'owner') {
                location.reload();
            } else {
                document.getElementById('daily-report-modal').classList.add('show');
            }
        }

        async function submitDailyReport() {
            let status = document.getElementById('rep-status').value;
            let gangguan = document.getElementById('rep-gangguan').value.trim();
            let perbaikan = document.getElementById('rep-perbaikan').value.trim();
            
            if (!perbaikan) {
                document.getElementById('rep-err-msg').style.display = 'block';
                return;
            }
            
            document.getElementById('daily-report-modal').classList.remove('show');
            showProcessAnim('Menyimpan Laporan Shift...', '');
            
            try {
                await fetch('/api/daily-reports', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ admin_name: activeUser, status, incidents: gangguan, repairs: perbaikan })
                });
            } catch(e) {}

            setTimeout(() => {
                location.reload();
            }, 1200);
        }

        /* --- DYNAMIC ISLAND ENGINE --- */
        function updateDynamicIsland(text, icon, expand = false) {
            const di = document.getElementById('dynamic-island');
            document.getElementById('di-icon').innerHTML = icon;
            document.getElementById('di-text').innerText = text;
            di.classList.remove('active', 'expand');
            void di.offsetWidth;
            di.classList.add('active');
            if (expand) di.classList.add('expand');
        }

        function hideDynamicIsland() {
            document.getElementById('dynamic-island').classList.remove('active', 'expand');
        }

        function handleIslandClick() {
            const di = document.getElementById('dynamic-island');
            if (di.classList.contains('active')) {
                if (document.getElementById('di-text').innerText.includes('Waiting')) {
                    document.getElementById('admin-waiting-modal').classList.add('show');
                }
            } else {
                toggleNotif();
            }
        }

        function toggleNotif() {
            document.getElementById('notif-panel').classList.toggle('show');
        }

        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('show');
            document.getElementById('sidebar-overlay').classList.toggle('show');
        }

        function toggleSubmenu(el) {
            const group = el.parentElement;
            if (group.classList.contains('expanded')) group.classList.remove('expanded');
            else {
                document.querySelectorAll('.nav-group').forEach(g => g.classList.remove('expanded'));
                group.classList.add('expanded');
            }
        }

        function switchView(viewId, el, isMain = false) {
            document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
            el.classList.add('active');
            if (isMain) document.querySelectorAll('.nav-group').forEach(g => g.classList.remove('expanded'));
            document.querySelectorAll('.view-section').forEach(s => s.classList.remove('active'));
            document.getElementById(viewId).classList.add('active');
            document.getElementById('topbar-title').innerText = el.innerText.replace(/[⚡📡🔌📶🚫🎛️📊🎫🛠️⚙️👑]/g,'').trim();
            document.querySelector('.sidebar').classList.remove('show');
            document.getElementById('sidebar-overlay').classList.remove('show');
        }

        function toggleFloatingWidget(e) {
            e.stopPropagation();
            const w = document.getElementById('floating-widget');
            if (w.classList.contains('collapsed')) {
                w.classList.remove('collapsed');
                w.classList.add('expanded');
            } else {
                w.classList.remove('expanded');
                w.classList.add('collapsed');
            }
        }

        function showProcessAnim(title, sub) {
            clearTimeout(processTimeout1);
            clearTimeout(processTimeout2);
            const morph = document.getElementById('anim-morph');
            morph.className = 'morph-wrapper is-loading';
            document.getElementById('anim-title').innerText = title;
            document.getElementById('anim-sub').innerText = sub;
            document.getElementById('process-modal').classList.add('show');
        }

        function finishProcessAnim(title, sub, status, autoClose = true) {
            const morph = document.getElementById('anim-morph');
            document.getElementById('anim-title').innerText = title;
            document.getElementById('anim-sub').innerText = sub;
            morph.className = status === 'success' ? 'morph-wrapper is-success' : 'morph-wrapper is-failed';
            document.getElementById('anim-title').style.color = status === 'success' ? 'var(--success)' : 'var(--danger)';
            if (autoClose) processTimeout1 = setTimeout(() => closeModal('process-modal'), 2400);
        }

        function closeModal(id) {
            document.getElementById(id).classList.remove('show');
        }
    </script>
</body>
</html>`;
}
