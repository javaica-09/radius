// ====================================================================
// REAL SUPABASE CLIENT (PostgREST) FOR CLOUDFLARE WORKERS
// Direct connection to Supabase PostgreSQL - Zero Fake / Zero Dummy
// ====================================================================

export class SupabaseClient {
  constructor(env) {
    this.env = env;
    this.url = env.SUPABASE_URL && !env.SUPABASE_URL.includes('your-project') 
      ? env.SUPABASE_URL.replace(/\/$/, '') 
      : null;
    this.key = env.SUPABASE_SERVICE_ROLE_KEY && !env.SUPABASE_SERVICE_ROLE_KEY.includes('your-supabase') 
      ? env.SUPABASE_SERVICE_ROLE_KEY 
      : (env.SUPABASE_ANON_KEY && !env.SUPABASE_ANON_KEY.includes('your-supabase') ? env.SUPABASE_ANON_KEY : null);
  }

  isConfigured() {
    return !!(this.url && this.key);
  }

  getHeaders(extra = {}) {
    return {
      'apikey': this.key,
      'Authorization': `Bearer ${this.key}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation',
      ...extra
    };
  }

  async select(table, query = '') {
    if (!this.isConfigured()) {
      console.warn(`[Supabase]: SUPABASE_URL atau KEY belum diatur di environment Cloudflare Workers.`);
      return [];
    }

    try {
      const res = await fetch(`${this.url}/rest/v1/${table}${query}`, {
        method: 'GET',
        headers: this.getHeaders()
      });
      if (!res.ok) {
        const errBody = await res.text();
        console.error(`[Supabase Select Error ${res.status} on ${table}]:`, errBody);
        return [];
      }
      return await res.json();
    } catch (err) {
      console.error(`[Supabase Fetch Failed on ${table}]:`, err.message);
      return [];
    }
  }

  async insert(table, record) {
    if (!this.isConfigured()) {
      throw new Error('Supabase belum dikonfigurasi.');
    }

    const res = await fetch(`${this.url}/rest/v1/${table}`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(record)
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Gagal insert ke ${table}: ${errText}`);
    }

    const data = await res.json();
    return Array.isArray(data) ? data[0] : data;
  }

  async update(table, filterKey, filterVal, updates) {
    if (!this.isConfigured()) {
      throw new Error('Supabase belum dikonfigurasi.');
    }

    const res = await fetch(`${this.url}/rest/v1/${table}?${filterKey}=eq.${encodeURIComponent(filterVal)}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(updates)
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Gagal update ${table}: ${errText}`);
    }

    return await res.json();
  }

  async delete(table, filterKey, filterVal) {
    if (!this.isConfigured()) {
      throw new Error('Supabase belum dikonfigurasi.');
    }

    const res = await fetch(`${this.url}/rest/v1/${table}?${filterKey}=eq.${encodeURIComponent(filterVal)}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });

    return res.ok;
  }

  async getSettings() {
    if (!this.isConfigured()) {
      return {
        mikrotik_host: this.env.MIKROTIK_HOST || '',
        mikrotik_port: this.env.MIKROTIK_PORT || '443',
        mikrotik_user: this.env.MIKROTIK_USER || 'admin',
        mikrotik_pass: this.env.MIKROTIK_PASS || '',
        radius_secret: this.env.RADIUS_SECRET || 'radsec123',
        tg_token: this.env.TELEGRAM_BOT_TOKEN || '',
        tg_chat: this.env.TELEGRAM_CHAT_ID || '',
        wa_url: this.env.WHATSAPP_GATEWAY_URL || '',
        wa_token: this.env.WHATSAPP_API_TOKEN || ''
      };
    }

    try {
      const rows = await this.select('system_settings');
      const map = {
        mikrotik_host: this.env.MIKROTIK_HOST || '',
        mikrotik_port: this.env.MIKROTIK_PORT || '443',
        mikrotik_user: this.env.MIKROTIK_USER || 'admin',
        mikrotik_pass: this.env.MIKROTIK_PASS || '',
        radius_secret: this.env.RADIUS_SECRET || 'radsec123',
        tg_token: this.env.TELEGRAM_BOT_TOKEN || '',
        tg_chat: this.env.TELEGRAM_CHAT_ID || '',
        wa_url: this.env.WHATSAPP_GATEWAY_URL || '',
        wa_token: this.env.WHATSAPP_API_TOKEN || ''
      };

      if (Array.isArray(rows)) {
        rows.forEach(r => {
          if (r.key && r.value) map[r.key] = r.value;
        });
      }
      return map;
    } catch (e) {
      return {};
    }
  }

  async setSetting(key, value) {
    if (!this.isConfigured()) return false;
    try {
      await fetch(`${this.url}/rest/v1/system_settings`, {
        method: 'POST',
        headers: this.getHeaders({ 'Prefer': 'resolution=merge-duplicates' }),
        body: JSON.stringify({ key, value, updated_at: new Date().toISOString() })
      });
      return true;
    } catch(e) {
      return false;
    }
  }

  async getFreezeState() {
    if (!this.isConfigured()) {
      return { is_frozen: false, frozen_by: null, reason: '', estimated_duration: '' };
    }
    const rows = await this.select('system_freeze', '?id=eq.1');
    return (rows && rows.length > 0) ? rows[0] : { is_frozen: false };
  }

  async setFreezeState(isFrozen, frozenBy, reason, duration) {
    if (!this.isConfigured()) return { is_frozen: isFrozen };
    await this.update('system_freeze', 'id', 1, {
      is_frozen: isFrozen,
      frozen_by: frozenBy,
      reason: reason || '',
      estimated_duration: duration || '',
      activated_at: isFrozen ? new Date().toISOString() : null
    });
    return this.getFreezeState();
  }
}
