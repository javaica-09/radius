// ====================================================================
// REAL MIKROTIK ROUTEROS v7 REST API CLIENT
// Direct communication with RouterOS v7 - Zero Mock / Zero Simulation
// ====================================================================

export class MikrotikClient {
  constructor(settings) {
    this.host = (settings.mikrotik_host || '').replace(/\/$/, '');
    this.port = settings.mikrotik_port || '443';
    this.user = settings.mikrotik_user || 'admin';
    this.pass = settings.mikrotik_pass || '';
  }

  isConfigured() {
    return !!(this.host && this.user);
  }

  getBaseUrl() {
    // If protocol not included, default to https
    let base = this.host;
    if (!base.startsWith('http://') && !base.startsWith('https://')) {
      base = `https://${base}`;
    }
    // Check if port is already part of the URL
    const urlObj = new URL(base);
    if (!urlObj.port && this.port && this.port !== '80' && this.port !== '443') {
      urlObj.port = this.port;
    }
    return urlObj.origin;
  }

  getHeaders() {
    const creds = btoa(`${this.user}:${this.pass}`);
    return {
      'Authorization': `Basic ${creds}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
  }

  async request(endpoint, method = 'GET', body = null) {
    if (!this.isConfigured()) {
      throw new Error('Host atau Username MikroTik belum dikonfigurasi di Pengaturan Sistem.');
    }

    const url = `${this.getBaseUrl()}/rest${endpoint.startsWith('/') ? endpoint : '/' + endpoint}`;
    const options = {
      method,
      headers: this.getHeaders()
    };

    if (body && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
      options.body = JSON.stringify(body);
    }

    try {
      const res = await fetch(url, options);
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`RouterOS HTTP ${res.status}: ${errorText || res.statusText}`);
      }
      return await res.json();
    } catch (err) {
      throw new Error(`Gagal menghubungi MikroTik (${url}): ${err.message}`);
    }
  }

  // 1. Hardware & System Resources
  async getSystemResource() {
    const [resResource, resIdentity] = await Promise.allSettled([
      this.request('/system/resource'),
      this.request('/system/identity')
    ]);

    if (resResource.status === 'rejected') {
      throw resResource.reason;
    }

    const r = resResource.value || {};
    const identityObj = resIdentity.status === 'fulfilled' ? resIdentity.value : {};

    return {
      identity: identityObj.name || 'MikroTik Router',
      boardName: r['board-name'] || r.platform || 'MikroTik',
      version: r.version || 'RouterOS v7',
      uptime: r.uptime || '-',
      cpuLoad: Number(r['cpu-load'] ?? 0),
      freeMemory: Number(r['free-memory'] ?? 0),
      totalMemory: Number(r['total-memory'] ?? 0),
      cpuCount: Number(r['cpu-count'] ?? 1),
      freeHddSpace: Number(r['free-hdd-space'] ?? 0),
      totalHddSpace: Number(r['total-hdd-space'] ?? 0)
    };
  }

  // 2. Real Interface Traffic
  async getInterfaceTraffic(interfaceName = 'ether1') {
    try {
      const data = await this.request('/interface/monitor-traffic', 'POST', {
        interface: interfaceName,
        once: true
      });
      const stat = Array.isArray(data) ? data[0] : data;
      return {
        rxBitsPerSecond: Number(stat['rx-bits-per-second'] || 0),
        txBitsPerSecond: Number(stat['tx-bits-per-second'] || 0),
        rxPacketsPerSecond: Number(stat['rx-packets-per-second'] || 0),
        txPacketsPerSecond: Number(stat['tx-packets-per-second'] || 0)
      };
    } catch (e) {
      // Fallback to reading accumulated counters from /interface
      try {
        const ifaces = await this.request('/interface');
        const match = Array.isArray(ifaces) ? ifaces.find(i => i.name === interfaceName) : null;
        if (match) {
          return {
            rxBitsPerSecond: Number(match['rx-byte'] || 0) * 8,
            txBitsPerSecond: Number(match['tx-byte'] || 0) * 8
          };
        }
      } catch(err2) {}
      throw e;
    }
  }

  // 3. Real Active PPPoE & Hotspot Clients from Router
  async getActiveSessions() {
    const [pppRes, hsRes] = await Promise.allSettled([
      this.request('/ppp/active'),
      this.request('/ip/hotspot/active')
    ]);

    const ppp = (pppRes.status === 'fulfilled' && Array.isArray(pppRes.value)) ? pppRes.value : [];
    const hs = (hsRes.status === 'fulfilled' && Array.isArray(hsRes.value)) ? hsRes.value : [];

    return {
      pppoe: ppp.map(s => ({
        id: s['.id'],
        user: s.name,
        service: s.service || 'pppoe',
        ip: s.address,
        mac: s['caller-id'] || '-',
        uptime: s.uptime,
        callerId: s['caller-id']
      })),
      hotspot: hs.map(h => ({
        id: h['.id'],
        user: h.user,
        ip: h.address,
        mac: h['mac-address'] || '-',
        uptime: h.uptime,
        bytesIn: Number(h['bytes-in'] || 0),
        bytesOut: Number(h['bytes-out'] || 0)
      }))
    };
  }

  // 4. Disconnect Client on MikroTik
  async disconnectClient(service, username) {
    if (service === 'pppoe' || service === 'ppp') {
      const actives = await this.request('/ppp/active');
      const target = Array.isArray(actives) ? actives.find(a => a.name === username) : null;
      if (target && target['.id']) {
        return await this.request(`/ppp/active/${encodeURIComponent(target['.id'])}`, 'DELETE');
      }
      throw new Error(`Sesi PPPoE aktif untuk '${username}' tidak ditemukan di router.`);
    } else if (service === 'hotspot') {
      const actives = await this.request('/ip/hotspot/active');
      const target = Array.isArray(actives) ? actives.find(a => a.user === username) : null;
      if (target && target['.id']) {
        return await this.request(`/ip/hotspot/active/${encodeURIComponent(target['.id'])}`, 'DELETE');
      }
      throw new Error(`Sesi Hotspot aktif untuk '${username}' tidak ditemukan di router.`);
    }
  }

  // 5. Real Router Ping Tool
  async ping(target, count = 4) {
    const res = await this.request('/tool/ping', 'POST', {
      address: target,
      count: Number(count)
    });
    return Array.isArray(res) ? res : [res];
  }

  // 6. Apply Bandwidth Limits to Queues
  async syncQueue(name, target, maxLimit) {
    // Check if queue exists
    const queues = await this.request('/queue/simple');
    const existing = Array.isArray(queues) ? queues.find(q => q.name === name) : null;

    if (existing && existing['.id']) {
      return await this.request(`/queue/simple/${encodeURIComponent(existing['.id'])}`, 'PATCH', {
        'max-limit': maxLimit
      });
    } else {
      return await this.request('/queue/simple', 'POST', {
        name: name,
        target: target,
        'max-limit': maxLimit
      });
    }
  }

  // 7. Reboot Router
  async reboot() {
    return await this.request('/system/reboot', 'POST', {});
  }
}
