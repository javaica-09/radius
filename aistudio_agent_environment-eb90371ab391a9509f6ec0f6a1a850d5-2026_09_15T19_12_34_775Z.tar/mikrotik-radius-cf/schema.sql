-- ====================================================================
-- MIKROTIK RADIUS CONTROL CENTER - SUPABASE POSTGRESQL SCHEMA
-- Clean Production Schema (No Dummy / No Fake Data)
-- Compatible with FreeRADIUS 3.x / RouterOS v7 REST & RADIUS AAA
-- ====================================================================

-- 1. FREERADIUS STANDARD TABLES
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS radcheck (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT '==',
    value VARCHAR(253) NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS radcheck_username_idx ON radcheck(username);

CREATE TABLE IF NOT EXISTS radreply (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT '=',
    value VARCHAR(253) NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS radreply_username_idx ON radreply(username);

CREATE TABLE IF NOT EXISTS radgroupcheck (
    id BIGSERIAL PRIMARY KEY,
    groupname VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT '==',
    value VARCHAR(253) NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS radgroupcheck_groupname_idx ON radgroupcheck(groupname);

CREATE TABLE IF NOT EXISTS radgroupreply (
    id BIGSERIAL PRIMARY KEY,
    groupname VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT '=',
    value VARCHAR(253) NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS radgroupreply_groupname_idx ON radgroupreply(groupname);

CREATE TABLE IF NOT EXISTS radusergroup (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    groupname VARCHAR(64) NOT NULL DEFAULT '',
    priority INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS radusergroup_username_idx ON radusergroup(username);

CREATE TABLE IF NOT EXISTS radacct (
    radacctid BIGSERIAL PRIMARY KEY,
    acctsessionid VARCHAR(64) NOT NULL DEFAULT '',
    acctuniqueid VARCHAR(32) NOT NULL DEFAULT '',
    username VARCHAR(64) NOT NULL DEFAULT '',
    groupname VARCHAR(64) DEFAULT '',
    realm VARCHAR(64) DEFAULT '',
    nasipaddress INET,
    nasportid VARCHAR(32) DEFAULT NULL,
    nasporttype VARCHAR(32) DEFAULT NULL,
    acctstarttime TIMESTAMPTZ DEFAULT NULL,
    acctupdatetime TIMESTAMPTZ DEFAULT NULL,
    acctstoptime TIMESTAMPTZ DEFAULT NULL,
    acctinterval INTEGER DEFAULT NULL,
    acctsessiontime BIGINT DEFAULT NULL,
    acctauthentic VARCHAR(32) DEFAULT NULL,
    connectinfo_start VARCHAR(128) DEFAULT NULL,
    connectinfo_stop VARCHAR(128) DEFAULT NULL,
    acctinputoctets BIGINT DEFAULT 0,
    acctoutputoctets BIGINT DEFAULT 0,
    calledstationid VARCHAR(50) NOT NULL DEFAULT '',
    callingstationid VARCHAR(50) NOT NULL DEFAULT '',
    acctterminatecause VARCHAR(32) NOT NULL DEFAULT '',
    servicetype VARCHAR(32) DEFAULT NULL,
    framedprotocol VARCHAR(32) DEFAULT NULL,
    framedipaddress INET DEFAULT NULL
);
CREATE INDEX IF NOT EXISTS radacct_username_idx ON radacct(username);
CREATE INDEX IF NOT EXISTS radacct_sessionid_idx ON radacct(acctsessionid);
CREATE INDEX IF NOT EXISTS radacct_starttime_idx ON radacct(acctstarttime);
CREATE INDEX IF NOT EXISTS radacct_stoptime_idx ON radacct(acctstoptime);

CREATE TABLE IF NOT EXISTS radpostauth (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    pass VARCHAR(64) NOT NULL DEFAULT '',
    reply VARCHAR(32) NOT NULL DEFAULT '',
    authdate TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    class VARCHAR(64) DEFAULT NULL
);
CREATE INDEX IF NOT EXISTS radpostauth_username_idx ON radpostauth(username);


-- 2. ISP BILLING & MANAGEMENT TABLES
-- --------------------------------------------------------------------

-- Admin accounts
CREATE TABLE IF NOT EXISTS admins (
    id SERIAL PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL DEFAULT '1234',
    pin_code VARCHAR(10) NOT NULL DEFAULT '1234',
    role VARCHAR(20) NOT NULL DEFAULT 'admin', -- 'owner' or 'admin'
    status VARCHAR(20) NOT NULL DEFAULT 'Active',
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Service Packages
CREATE TABLE IF NOT EXISTS packages (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    service_type VARCHAR(20) NOT NULL DEFAULT 'pppoe', -- 'pppoe' or 'hotspot'
    rate_limit VARCHAR(50) NOT NULL DEFAULT '10M/10M', -- 'Download/Upload' (Mikrotik-Rate-Limit)
    burst_limit VARCHAR(50) DEFAULT NULL,
    pool_name VARCHAR(50) NOT NULL DEFAULT 'pool-pppoe',
    isolir_pool VARCHAR(50) NOT NULL DEFAULT 'pool-isolir',
    price NUMERIC(12,2) NOT NULL DEFAULT 0,
    duration_days INT NOT NULL DEFAULT 30,
    shared_users INT NOT NULL DEFAULT 1,
    quota_bytes BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ISP Customers (PPPoE / Static Hotspot)
CREATE TABLE IF NOT EXISTS customers (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    password VARCHAR(64) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(30),
    address TEXT,
    service_type VARCHAR(20) NOT NULL DEFAULT 'pppoe', -- 'pppoe' or 'hotspot'
    package_name VARCHAR(50) REFERENCES packages(name) ON UPDATE CASCADE ON DELETE SET NULL,
    ip_address VARCHAR(50) DEFAULT 'Auto (DHCP)',
    mac_address VARCHAR(50) DEFAULT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'connected', -- 'connected', 'disconnected', 'isolated'
    billing_due_date DATE DEFAULT (CURRENT_DATE + INTERVAL '30 days'),
    monthly_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
    device_model VARCHAR(50) DEFAULT NULL,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Hotspot Vouchers (Batch Generated)
CREATE TABLE IF NOT EXISTS vouchers (
    id SERIAL PRIMARY KEY,
    code VARCHAR(64) UNIQUE NOT NULL,
    password VARCHAR(64) NOT NULL,
    package_name VARCHAR(50) REFERENCES packages(name) ON UPDATE CASCADE ON DELETE SET NULL,
    price NUMERIC(12,2) NOT NULL DEFAULT 5000,
    duration_hours INT NOT NULL DEFAULT 5,
    quota_mb INT NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'unused', -- 'unused', 'active', 'expired'
    batch_name VARCHAR(50) DEFAULT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    activated_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ
);

-- Invoices & Transactions
CREATE TABLE IF NOT EXISTS invoices (
    id SERIAL PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT REFERENCES customers(id) ON DELETE CASCADE,
    customer_name VARCHAR(100) NOT NULL,
    package_name VARCHAR(50),
    amount NUMERIC(12,2) NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'unpaid', -- 'paid', 'unpaid', 'cancelled'
    due_date DATE NOT NULL DEFAULT CURRENT_DATE,
    paid_at TIMESTAMPTZ,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tickets & Client Requests
CREATE TABLE IF NOT EXISTS tickets (
    id SERIAL PRIMARY KEY,
    ticket_number VARCHAR(30) UNIQUE NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    category VARCHAR(30) NOT NULL DEFAULT 'Kendala', -- 'Kendala', 'PPPoE', 'Hotspot'
    priority VARCHAR(20) NOT NULL DEFAULT 'Normal', -- 'Low', 'Normal', 'High', 'Critical'
    notes TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'Open', -- 'Open', 'In Progress', 'Closed'
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Owner Approvals Queue
CREATE TABLE IF NOT EXISTS approvals (
    id SERIAL PRIMARY KEY,
    request_id VARCHAR(30) UNIQUE NOT NULL,
    requester_name VARCHAR(50) NOT NULL,
    risk_level VARCHAR(30) NOT NULL DEFAULT 'Configuration', -- 'Critical', 'Configuration', 'Normal'
    command TEXT NOT NULL,
    device VARCHAR(50) DEFAULT 'Dashboard Action',
    router VARCHAR(50) DEFAULT 'MikroTik-Router',
    status VARCHAR(20) NOT NULL DEFAULT 'Pending', -- 'Pending', 'Approved', 'Rejected', 'Hold'
    reviewer_notes TEXT,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reviewed_at TIMESTAMPTZ
);

-- System Audit Trail Logs
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    actor VARCHAR(50) NOT NULL,
    role VARCHAR(30) NOT NULL DEFAULT 'admin',
    action VARCHAR(100) NOT NULL,
    target VARCHAR(150) NOT NULL,
    authorization_status VARCHAR(50) NOT NULL DEFAULT 'PIN Sukses',
    ip_address VARCHAR(50) DEFAULT '127.0.0.1',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Daily Reports (Admin Handover on Logout)
CREATE TABLE IF NOT EXISTS daily_reports (
    id SERIAL PRIMARY KEY,
    report_date DATE NOT NULL DEFAULT CURRENT_DATE,
    admin_name VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Normal',
    incidents TEXT,
    repairs TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- System Freeze Mode (Lockdown)
CREATE TABLE IF NOT EXISTS system_freeze (
    id INT PRIMARY KEY DEFAULT 1,
    is_frozen BOOLEAN NOT NULL DEFAULT FALSE,
    frozen_by VARCHAR(50),
    reason TEXT DEFAULT 'Emergency maintenance',
    estimated_duration VARCHAR(50) DEFAULT '60 Menit',
    activated_at TIMESTAMPTZ
);

-- System Key-Value Settings
CREATE TABLE IF NOT EXISTS system_settings (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- 3. STORED FUNCTIONS & TRIGGERS (SYNC CUSTOMER -> RADCHECK & RADREPLY)
-- --------------------------------------------------------------------

CREATE OR REPLACE FUNCTION sync_customer_to_radius()
RETURNS TRIGGER AS $$
DECLARE
    pkg_rate VARCHAR(50);
    pkg_pool VARCHAR(50);
BEGIN
    -- Query package defaults
    SELECT rate_limit, pool_name INTO pkg_rate, pkg_pool 
    FROM packages WHERE name = NEW.package_name LIMIT 1;
    
    IF pkg_rate IS NULL THEN pkg_rate := '20M/10M'; END IF;
    IF pkg_pool IS NULL THEN pkg_pool := 'pool-pppoe'; END IF;

    -- If customer status is isolated, restrict to 128k and isolir pool
    IF NEW.status = 'isolated' THEN
        pkg_rate := '128k/128k';
        pkg_pool := 'pool-isolir';
    END IF;

    -- Update or insert into radcheck (Cleartext-Password)
    DELETE FROM radcheck WHERE username = NEW.username AND attribute = 'Cleartext-Password';
    INSERT INTO radcheck (username, attribute, op, value)
    VALUES (NEW.username, 'Cleartext-Password', ':=', NEW.password);

    -- Update or insert into radreply (Mikrotik-Rate-Limit)
    DELETE FROM radreply WHERE username = NEW.username AND attribute = 'Mikrotik-Rate-Limit';
    INSERT INTO radreply (username, attribute, op, value)
    VALUES (NEW.username, 'Mikrotik-Rate-Limit', ':=', pkg_rate);

    -- Update or insert into radreply (Framed-Pool)
    DELETE FROM radreply WHERE username = NEW.username AND attribute = 'Framed-Pool';
    INSERT INTO radreply (username, attribute, op, value)
    VALUES (NEW.username, 'Framed-Pool', ':=', pkg_pool);

    -- If Static IP is defined
    IF NEW.ip_address IS NOT NULL AND NEW.ip_address <> '' AND NEW.ip_address NOT LIKE '%Auto%' THEN
        DELETE FROM radreply WHERE username = NEW.username AND attribute = 'Framed-IP-Address';
        INSERT INTO radreply (username, attribute, op, value)
        VALUES (NEW.username, 'Framed-IP-Address', ':=', NEW.ip_address);
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_customer_radius ON customers;
CREATE TRIGGER trg_sync_customer_radius
AFTER INSERT OR UPDATE ON customers
FOR EACH ROW EXECUTE FUNCTION sync_customer_to_radius();

-- Cleanup trigger when customer is deleted
CREATE OR REPLACE FUNCTION cleanup_customer_radius()
RETURNS TRIGGER AS $$
BEGIN
    DELETE FROM radcheck WHERE username = OLD.username;
    DELETE FROM radreply WHERE username = OLD.username;
    DELETE FROM radusergroup WHERE username = OLD.username;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_cleanup_customer_radius ON customers;
CREATE TRIGGER trg_cleanup_customer_radius
AFTER DELETE ON customers
FOR EACH ROW EXECUTE FUNCTION cleanup_customer_radius();


-- 4. INITIAL BASE SETUP (NO DUMMY / NO FAKE DATA)
-- --------------------------------------------------------------------

-- Super Admin account only (for initial login)
INSERT INTO admins (full_name, username, password, pin_code, role, status)
VALUES 
    ('System Owner', 'super_admin', '1234', '1234', 'owner', 'Active')
ON CONFLICT (username) DO NOTHING;

-- Base default service packages
INSERT INTO packages (name, service_type, rate_limit, pool_name, isolir_pool, price, duration_days, shared_users)
VALUES 
    ('VIP_100M', 'pppoe', '100M/50M', 'pool-pppoe', 'pool-isolir', 350000, 30, 1),
    ('REG_50M', 'pppoe', '50M/10M', 'pool-pppoe', 'pool-isolir', 200000, 30, 1),
    ('REG_20M', 'pppoe', '20M/5M', 'pool-pppoe', 'pool-isolir', 150000, 30, 1),
    ('Voucher_5Jam', 'hotspot', '5M/2M', 'pool-hotspot', 'pool-isolir', 5000, 1, 1),
    ('Voucher_24Jam', 'hotspot', '10M/5M', 'pool-hotspot', 'pool-isolir', 15000, 1, 1)
ON CONFLICT (name) DO NOTHING;

-- Base system settings
INSERT INTO system_settings (key, value, description)
VALUES 
    ('mikrotik_host', 'https://192.168.88.1', 'MikroTik RouterOS v7 Host IP or Domain'),
    ('mikrotik_port', '443', 'MikroTik REST API Port'),
    ('mikrotik_user', 'admin', 'RouterOS API Username'),
    ('mikrotik_pass', '', 'RouterOS API Password'),
    ('radius_secret', 'radsec123', 'RADIUS Shared Secret'),
    ('tg_token', '', 'Telegram Bot Token'),
    ('tg_chat', '', 'Telegram Chat/Group ID'),
    ('wa_url', '', 'WhatsApp Gateway Server URL'),
    ('wa_token', '', 'WhatsApp Gateway Auth Token')
ON CONFLICT (key) DO NOTHING;

-- Base freeze state
INSERT INTO system_freeze (id, is_frozen, frozen_by, reason, estimated_duration)
VALUES (1, FALSE, NULL, '', '')
ON CONFLICT (id) DO NOTHING;
