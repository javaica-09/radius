# MikroTik RADIUS Control Center — Enterprise Pro
### iOS 27 Liquid Glass Light Theme &bull; Cloudflare Workers &bull; Supabase Database

Website Management RADIUS Server terpadu & REST API untuk MikroTik RouterOS v7, dirancang khusus untuk berjalan di atas **Cloudflare Workers (Serverless Edge)** dengan database **Supabase (PostgreSQL)**, dibalut desain antarmuka **iOS 27 Liquid Glass Tema Terang (Light Mode)**.

---

## 🌟 Fitur Unggulan

1. **iOS 27 Liquid Glass Light Theme**:
   - Background cairan organik (*Dynamic Fluid Mesh Gradient*) dengan animasi orbs berpendar halus.
   - Panel kaca ultra-frosted (`backdrop-filter: blur(40px) saturate(200%)`) dengan batas pantulan dinamis (*specular reflection*).
   - **Dynamic Island v2**: Kapsul notifikasi interaktif yang dapat bermutasi menjadi loader, status otorisasi, atau notifikasi persetujuan Owner.
   - Tipografi Apple SF Pro, tombol tactile spring Cupertino, dan haptics feedback visual.

2. **Alur Autentikasi & Keamanan Berlapis**:
   - **Splash Screen Typewriter**: Animasi ketik identitas `_uvwxyz` Powered by JAVAICA.
   - **Morning System Checklist**: 15 titik pengecekan otomatis (MikroTik API, FreeRADIUS, Supabase DB, PPPoE, Hotspot, WhatsApp, Telegram, CPU, Memory, Disk, dsb.).
   - **Admin PIN Pad 4-Digit**: Papan tombol numerik sentuh dengan getaran visual.
   - **Smart Greeting Screen**: Sambutan waktu cerdas (*Pagi, Siang, Sore, Malam*), ringkasan metrik harian, dan kutipan operasional.

3. **Manajemen RADIUS & MikroTik Lengkap**:
   - **RADIUS Active Sessions (Radacct)**: Memantau sesi pelanggan aktif secara real-time, penggunaan byte data (Upload / Download octets), Session Time, Framed IP, dan MAC Address. Dilengkapi tombol pemutus koneksi instan (**CoA / Disconnect**).
   - **PPPoE RADIUS Management**: Tambah/edit rahasia PPPoE yang otomatis tersinkron ke tabel `radcheck` dan `radreply` Supabase (`Mikrotik-Rate-Limit` dan `Framed-Pool`).
   - **Hotspot RADIUS Management**: Manajemen pengguna voucher dan akun statis.
   - **Batch Voucher Generator & Thermal Print**: Generate ratusan voucher dalam hitungan detik berdasarkan masa aktif (1 Jam, 5 Jam, 24 Jam, 7 Hari, 30 Hari), harga, dan kuota. Dilengkapi cetak struk thermal POS dan kartu voucher dengan QR Code.
   - **MikroTik RouterOS v7 RADIUS Setup Generator**: Skrip terminal RouterOS satu klik salin untuk menghubungkan router ke server RADIUS ini.

4. **Isolir Terpadu Pelanggan**:
   - **Mass Isolir Tagihan**: Satu tombol mengalihkan seluruh pelanggan menunggak ke profil isolir (`pool-isolir` dengan limit `128k/128k` dan redirect web tagihan).
   - **Mass Isolir Maintenance**: Pemeliharaan terpusat.
   - **Un-Isolir 1-Klik**: Mengembalikan limitasi dan IP pool asli pelanggan seketika.

5. **Visual Bandwidth Matrix (Traffic Shaper)**:
   - Slider interaktif alokasi bandwith (PPPoE VIP, PPPoE Regular, Hotspot Shared, Headroom).
   - Real-time Donut Chart visualisasi distribusi bandwith.
   - Tombol penerapan langsung ke Simple Queue / Queue Tree MikroTik.

6. **Diagnostik Jaringan**:
   - **Speedtest / Bandwidth Test**: Speedometer canvas dinamis yang menguji Throughput Download, Upload, Latensi Ping, dan Jitter.
   - **Ping & Traceroute Terminal**: Konsol pengujian ICMP langsung dengan formatting RouterOS v7.

7. **Owner Console & Persetujuan Khusus**:
   - **Approval Center**: Meninjau instruksi sensitif (Risk Badge: *Critical* / *Configuration*), Mini Console eksekusi, serta keputusan Approve / Reject / Hold yang terhubung dengan notifikasi Telegram Bot.
   - **System Freeze**: Penguncian darurat seluruh sistem (*Read-Only Mode*) untuk mencegah kesalahan konfigurasi staf.
   - **Admin Shift Handover**: Formulir wajib isi sebelum admin melakukan logout untuk pencatatan pergantian shift.
   - **Audit Trail Log**: Riwayat menyeluruh aktivitas admin beserta timestamp dan status otorisasi.

---

## 📁 Struktur Direktori Proyek

```
/mikrotik-radius-cf
├── schema.sql           # Skema lengkap Supabase PostgreSQL (FreeRADIUS + Billing)
├── wrangler.toml        # Konfigurasi Cloudflare Workers & Environment Variables
├── package.json         # Konfigurasi project NPM (ES Module)
├── README.md            # Dokumentasi lengkap instalasi dan deployment
├── src/
│   ├── worker.js        # Worker utama (REST API AAA, RouterOS Proxy & Controller)
│   ├── template.js      # Frontend Template (iOS 27 Liquid Glass Single-Page App)
│   └── supabase.js      # Klien Supabase PostgREST & Fallback In-Memory Engine
└── public/
    └── index.html       # Standalone Static HTML Build (Opsional / Preview)
```

---

## 🚀 Panduan 1: Persiapan Database Supabase

1. Buat project baru di [Supabase Dashboard](https://supabase.com).
2. Masuk ke menu **SQL Editor** pada panel Supabase Anda.
3. Buka file `schema.sql` pada proyek ini, salin seluruh kodenya, lalu klik tombol **Run**.
4. Skema ini secara otomatis akan membuat:
   - Tabel standar FreeRADIUS: `radcheck`, `radreply`, `radgroupcheck`, `radgroupreply`, `radusergroup`, `radacct`, `radpostauth`.
   - Tabel Billing & ISP: `customers`, `packages`, `vouchers`, `invoices`, `tickets`, `approvals`, `admins`, `audit_logs`, `system_settings`, `daily_reports`, `system_freeze`.
   - **Trigger Otomatis**: Setiap penambahan pelanggan di `customers` otomatis menyinkronkan password ke `radcheck` dan rate limit ke `radreply`. Pelanggan berstatus `isolated` otomatis diset ke `pool-isolir` dan `128k/128k`.
   - Data awal administrator (`super_admin` / `1234`, PIN `1234`).
5. Buka **Project Settings** &rarr; **API**, salin:
   - `Project URL` (misal: `https://xyzcompany.supabase.co`)
   - `service_role` secret key (atau `anon` public key).

---

## ☁️ Panduan 2: Deploy ke Cloudflare Workers

### Opsi A: Menggunakan Wrangler CLI (Rekomendasi)

1. Pastikan Anda telah memiliki Node.js dan Wrangler CLI:
   ```bash
   npm install -g wrangler
   ```
2. Buka file `wrangler.toml`, sesuaikan variabel lingkungan:
   ```toml
   [vars]
   SUPABASE_URL = "https://your-project.supabase.co"
   SUPABASE_ANON_KEY = "your-supabase-anon-key"
   SUPABASE_SERVICE_ROLE_KEY = "your-supabase-service-role-key"
   RADIUS_SECRET = "radsec123"
   MIKROTIK_HOST = "https://192.168.88.1"
   MIKROTIK_PORT = "443"
   MIKROTIK_USER = "admin"
   MIKROTIK_PASS = "1234"
   TELEGRAM_BOT_TOKEN = ""
   TELEGRAM_CHAT_ID = ""
   WHATSAPP_GATEWAY_URL = "http://localhost:3000"
   WHATSAPP_API_TOKEN = ""
   ```
3. Login dan deploy langsung ke edge Cloudflare:
   ```bash
   wrangler login
   wrangler deploy
   ```
4. Selesai! Worker Anda akan aktif secara instan pada URL `https://mikrotik-radius-control.<subdomain>.workers.dev`.

### Opsi B: Deploy Melalui Cloudflare Dashboard (Tanpa CLI)

1. Buka [Cloudflare Dashboard](https://dash.cloudflare.com) &rarr; **Workers & Pages** &rarr; **Create application**.
2. Beri nama worker (misal: `radius-mikrotik`).
3. Tempelkan kode dari file `src/worker.js`, `src/template.js`, dan `src/supabase.js`.
4. Buka tab **Settings** &rarr; **Variables and Secrets**, tambahkan `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `RADIUS_SECRET`, dll.
5. Klik **Save and Deploy**.

---

## 📡 Panduan 3: Konfigurasi MikroTik RouterOS v7

Buka terminal MikroTik (Winbox / SSH) dan jalankan konfigurasi berikut:

```routeros
# 1. Tambahkan RADIUS Server (Arahkan ke IP Server / FreeRADIUS Gateway)
/radius add address=192.168.88.10 secret="radsec123" service=hotspot,pppoe comment="Cloud RADIUS Supabase" timeout=3000ms

# 2. Aktifkan port CoA (Change of Authorization) untuk Disconnect instan
/radius incoming set accept=yes port=3799

# 3. Aktifkan otentikasi RADIUS pada Server PPPoE
/interface pppoe-server server set [find] use-radius=yes authentication=pap,chap,mschap2

# 4. Aktifkan otentikasi RADIUS pada Profil Hotspot
/ip hotspot profile set [find] use-radius=yes

# 5. Buat Pool & Firewall Isolir
/ip pool add name=pool-isolir ranges=192.168.99.2-192.168.99.254
/ip firewall nat add chain=srcnat action=masquerade src-address=192.168.99.0/24 comment="NAT Pool Isolir"
/ip firewall nat add chain=dstnat protocol=tcp dst-port=80,443 src-address=192.168.99.0/24 action=redirect to-ports=8080 comment="Redirect Web Isolir"

# 6. Aktifkan REST API RouterOS v7 (untuk monitoring hardware & diagnostic)
/ip service set www-ssl port=443 disabled=no
/ip service set www port=80 disabled=no
```

---

## 🔌 Panduan 4: Integrasi FreeRADIUS (rlm_rest atau PostgreSQL)

Sistem ini mendukung dua metode integrasi FreeRADIUS:

### Cara 1: Menggunakan Modul `rlm_rest` (Terhubung ke Cloudflare Worker)
FreeRADIUS memanggil API Cloudflare Worker secara langsung via HTTP/REST:
- Pada `/etc/freeradius/3.0/mods-available/rest`:
  ```unlang
  rest {
      connect_uri = "https://mikrotik-radius-control.your-worker.workers.dev/api/radius"
      authenticate {
          uri = "${..connect_uri}/authorize"
          method = "post"
          body = "json"
          data = '{"username": "%{User-Name}", "password": "%{User-Password}"}'
      }
      accounting {
          uri = "${..connect_uri}/accounting"
          method = "post"
          body = "json"
          data = '{"User-Name": "%{User-Name}", "Acct-Status-Type": "%{Acct-Status-Type}", "Acct-Session-Id": "%{Acct-Session-Id}", "Acct-Input-Octets": "%{Acct-Input-Octets}", "Acct-Output-Octets": "%{Acct-Output-Octets}", "Acct-Session-Time": "%{Acct-Session-Time}", "Framed-IP-Address": "%{Framed-IP-Address}", "Calling-Station-Id": "%{Calling-Station-Id}"}'
      }
  }
  ```

### Cara 2: Direct PostgreSQL (FreeRADIUS ke Supabase Connection Pooling)
Jika Anda menggunakan FreeRADIUS standar pada server Linux, Anda dapat menghubungkannya langsung ke Supabase menggunakan port `5432` atau `6543` (Connection Pooler):
- Pada `/etc/freeradius/3.0/mods-available/sql`:
  ```unlang
  sql {
      dialect = "postgresql"
      driver = "rlm_sql_postgresql"
      server = "aws-0-ap-southeast-1.pooler.supabase.com"
      port = 6543
      login = "postgres.your-project"
      password = "your-database-password"
      radius_db = "postgres"
      read_clients = yes
      client_table = "nas"
  }
  ```

---

## 🔑 Kredensial Login Default

| Tipe Akun | Username | Password | PIN Otorisasi | Hak Akses |
|---|---|---|---|---|
| **Owner (Super Admin)** | `super_admin` | `1234` | `1234` | Akses penuh, Approval Center, System Freeze |
| **Admin Staf** | `admin_toni` | `1234` | `1234` | Manajemen Client, Voucher, Tiket, Butuh Approval Owner untuk aksi sensitif |

---

## 🛠️ API Reference Ringkas

| Method | Endpoint | Deskripsi |
|---|---|---|
| `GET` | `/` | Web Application iOS 27 Liquid Glass |
| `POST` | `/api/auth/login` | Login user administrator |
| `POST` | `/api/auth/verify-pin` | Verifikasi 4 digit PIN keamanan |
| `GET/POST` | `/api/radius/authorize` | FreeRADIUS AAA Auth Check (Accept / Reject) |
| `POST` | `/api/radius/accounting` | FreeRADIUS Accounting Start/Interim/Stop |
| `GET` | `/api/radius/sessions` | Data sesi aktif radacct dengan octets data |
| `POST` | `/api/radius/vouchers/generate` | Generate batch voucher hotspot |
| `GET` | `/api/radius/vouchers` | Daftar voucher yang tersedia |
| `GET` | `/api/mikrotik/status` | Live CPU, Memory, Disk, Uptime, Interface Traffic |
| `GET` | `/api/mikrotik/clients` | Daftar terpadu PPPoE & Hotspot active clients |
| `POST` | `/api/mikrotik/action` | Eksekusi reboot, queue update, disconnect |
| `GET` | `/api/mikrotik/ping?target=...` | Ping diagnostic ICMP |
| `GET/POST`| `/api/tickets` | Tiket gangguan & request pasang baru |
| `GET/POST`| `/api/approvals` | Owner approval queue & webhook status |
| `GET/POST`| `/api/settings` | Konfigurasi MikroTik, Telegram, WhatsApp |

---

*Hak Cipta &copy; 2026 &bull; Dibuat dengan presisi untuk performa ISP modern &bull; Powered by JAVAICA.*
